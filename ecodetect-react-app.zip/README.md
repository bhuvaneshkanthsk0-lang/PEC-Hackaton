# EcoDetect

React + Vite + Tailwind CSS dashboard UI.

## Setup

```bash
npm install
npm run dev
```

Then open the local URL Vite prints (usually http://localhost:5173).

## Build

```bash
npm run build
npm run preview
```

## Structure

- `src/App.jsx` — the whole dashboard: sidebar (all 11 nav items), home page
  (welcome header, profile card, feature cards, stats bar, recent activity,
  footer), and click-through placeholder pages for every other nav item.
- `src/main.jsx` — React entry point.
- `src/index.css` — Tailwind entry.

Click any sidebar item, or a feature card's action button, to switch pages.
Only the Home page is fully built out — the rest are placeholders ready for
you to fill in.
