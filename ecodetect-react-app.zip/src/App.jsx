import React, { useState } from "react";
import {
  Home,
  ShoppingBag,
  ScanLine,
  Recycle,
  FileText,
  Heart,
  Trophy,
  Clock,
  User,
  Settings,
  HelpCircle,
  Bell,
  ChevronDown,
  Star,
  MapPin,
  Calendar,
  Leaf,
  Camera,
  Wind,
  MapPinned,
  Gift,
  Globe,
  Award,
} from "lucide-react";

const NAV_ITEMS = [
  { id: "home", label: "Home", icon: Home },
  { id: "store", label: "Store", icon: ShoppingBag },
  { id: "detect", label: "AI Waste Detection", icon: ScanLine },
  { id: "recycle", label: "Recycle Value", icon: Recycle },
  { id: "reporting", label: "Smart Reporting", icon: FileText },
  { id: "rewards", label: "Rewards", icon: Heart },
  { id: "leaderboard", label: "Leaderboard", icon: Trophy },
  { id: "history", label: "History", icon: Clock },
  { id: "profile", label: "Profile", icon: User },
  { id: "settings", label: "Settings", icon: Settings },
  { id: "help", label: "Help & Support", icon: HelpCircle },
];

const FEATURES = [
  {
    n: "01",
    icon: ScanLine,
    iconBg: "bg-blue-100",
    iconColor: "text-blue-500",
    title: "AI Waste Detection",
    titleColor: "text-blue-600",
    desc: "Identify waste type instantly using a photo.",
    btnBg: "bg-blue-500 hover:bg-blue-600",
    btnLabel: "Detect Now",
    tab: "detect",
  },
  {
    n: "02",
    icon: Recycle,
    iconBg: "bg-green-100",
    iconColor: "text-green-600",
    title: "Recycling Value Estimation",
    titleColor: "text-green-700",
    desc: "Display the estimated recycling/scrap value.",
    btnBg: "bg-green-600 hover:bg-green-700",
    btnLabel: "Check Value",
    tab: "recycle",
  },
  {
    n: "03",
    icon: MapPinned,
    iconBg: "bg-orange-100",
    iconColor: "text-orange-500",
    title: "Smart Waste Reporting",
    titleColor: "text-orange-500",
    desc: "Report public waste with photo and GPS location.",
    btnBg: "bg-orange-500 hover:bg-orange-600",
    btnLabel: "Report Now",
    tab: "reporting",
  },
  {
    n: "04",
    icon: Gift,
    iconBg: "bg-purple-100",
    iconColor: "text-purple-500",
    title: "Reward & Leaderboard",
    titleColor: "text-purple-600",
    desc: "Earn points for verified reports and recycling.",
    btnBg: "bg-purple-500 hover:bg-purple-600",
    btnLabel: "View Leaderboard",
    tab: "leaderboard",
  },
];

const ACTIVITY = [
  {
    icon: Recycle,
    iconBg: "bg-green-100",
    iconColor: "text-green-600",
    text: "You scanned Plastic Bottle",
    time: "2 hrs ago",
    pts: "+10 pts",
  },
  {
    icon: MapPin,
    iconBg: "bg-red-100",
    iconColor: "text-red-500",
    text: "You reported illegal waste",
    time: "1 day ago",
    pts: "+15 pts",
  },
  {
    icon: Recycle,
    iconBg: "bg-green-100",
    iconColor: "text-green-600",
    text: "You recycled 2 kg Plastic",
    time: "2 days ago",
    pts: "+20 pts",
  },
  {
    icon: Gift,
    iconBg: "bg-red-100",
    iconColor: "text-red-500",
    text: 'You earned "Eco Champion" badge',
    time: "3 days ago",
    pts: "+25 pts",
  },
];

const STATS = [
  { icon: Leaf, iconColor: "text-green-600", value: "128", label: "Waste Detected" },
  { icon: Recycle, iconColor: "text-green-600", value: "56 kg", label: "Waste Recycled" },
  { icon: "co2", iconColor: "text-sky-500", value: "210 kg", label: "CO₂ Saved" },
  { icon: User, iconColor: "text-green-600", value: "342", label: "Active Users" },
];

function Sidebar({ active, onSelect }) {
  return (
    <aside className="w-64 shrink-0 bg-white border-r border-gray-100 flex flex-col h-screen sticky top-0">
      <div className="flex items-center gap-3 px-6 pt-6 pb-5">
        <div className="w-11 h-11 rounded-full bg-gradient-to-br from-green-400 to-green-600 flex items-center justify-center">
          <Recycle className="w-6 h-6 text-white" />
        </div>
        <div>
          <div className="text-lg font-bold text-gray-900 leading-tight">EcoDetect</div>
          <div className="text-[11px] text-gray-400 leading-tight">Detect. Report. Recycle. Reward.</div>
        </div>
      </div>

      <nav className="flex-1 px-3 space-y-1 overflow-y-auto">
        {NAV_ITEMS.map((item) => {
          const Icon = item.icon;
          const isActive = active === item.id;
          return (
            <button
              key={item.id}
              onClick={() => onSelect(item.id)}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors ${
                isActive
                  ? "bg-green-50 text-green-700"
                  : "text-gray-600 hover:bg-gray-50"
              }`}
            >
              <Icon className={`w-[18px] h-[18px] ${isActive ? "text-green-700" : "text-gray-400"}`} />
              <span>{item.label}</span>
            </button>
          );
        })}
      </nav>

      <div className="p-4">
        <div className="relative overflow-hidden rounded-2xl bg-green-50 p-5">
          <div className="relative z-10">
            <p className="text-sm font-bold text-gray-900 leading-snug">
              Small actions, big impact.
            </p>
            <p className="text-xs text-gray-500 mt-1">Be a part of the solution.</p>
          </div>
          <div className="mt-6 flex items-end justify-center gap-2 h-14">
            <div className="w-5 h-8 bg-green-300 rounded-t-full" />
            <div className="w-5 h-12 bg-green-400 rounded-t-full" />
            <Wind className="w-6 h-6 text-green-500 mb-1" />
            <div className="w-5 h-10 bg-green-300 rounded-t-full" />
          </div>
        </div>
      </div>
    </aside>
  );
}

function TopBar({ name }) {
  return (
    <div className="flex items-start justify-between mb-6">
      <div>
        <h1 className="text-2xl font-bold text-gray-900">Welcome back,</h1>
        <h2 className="text-2xl font-bold text-green-600 flex items-center gap-2">
          {name} <Leaf className="w-5 h-5 text-green-500" />
        </h2>
        <p className="text-gray-400 text-sm mt-1">
          Together, let's build a cleaner and greener tomorrow.
        </p>
      </div>
      <div className="flex items-center gap-3">
        <div className="flex items-center gap-1.5 bg-white border border-gray-200 rounded-full px-4 py-2 text-sm font-semibold text-gray-700 shadow-sm">
          <Star className="w-4 h-4 text-amber-400 fill-amber-400" />
          Credits <span className="text-gray-900">120</span>
        </div>
        <button className="relative w-10 h-10 rounded-full bg-white border border-gray-200 flex items-center justify-center shadow-sm">
          <Bell className="w-[18px] h-[18px] text-gray-500" />
          <span className="absolute top-2 right-2.5 w-1.5 h-1.5 bg-green-500 rounded-full" />
        </button>
        <div className="w-10 h-10 rounded-full bg-gray-200 flex items-center justify-center overflow-hidden">
          <User className="w-5 h-5 text-gray-400" />
        </div>
        <ChevronDown className="w-4 h-4 text-gray-400" />
      </div>
    </div>
  );
}

function ProfileCard({ name }) {
  return (
    <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-green-50 to-green-100 p-6 flex items-center gap-6">
      <div className="absolute inset-0 flex items-end justify-end opacity-70 pointer-events-none">
        <div className="flex items-end gap-1 pr-6 pb-0">
          <div className="w-8 h-16 bg-green-200 rounded-t-md" />
          <div className="w-8 h-24 bg-green-300 rounded-t-md" />
          <div className="w-8 h-14 bg-green-200 rounded-t-md" />
          <Wind className="w-10 h-10 text-green-400 mb-2" />
          <Wind className="w-8 h-8 text-green-300 mb-6" />
        </div>
      </div>

      <div className="relative shrink-0">
        <div className="w-24 h-24 rounded-full bg-gradient-to-br from-green-500 to-green-700 flex items-center justify-center">
          <Leaf className="w-10 h-10 text-white" />
        </div>
        <div className="absolute -bottom-1 -right-1 w-8 h-8 rounded-full bg-gray-900 flex items-center justify-center border-2 border-white">
          <Camera className="w-4 h-4 text-white" />
        </div>
      </div>

      <div className="relative flex-1 min-w-[220px]">
        <h3 className="text-xl font-bold text-gray-900">{name}</h3>
        <div className="mt-2 space-y-1.5 text-sm text-gray-600">
          <div className="flex items-center gap-2">
            <Award className="w-4 h-4 text-green-600" />
            <span>Eco Warrior</span>
          </div>
          <div className="flex items-center gap-2">
            <MapPin className="w-4 h-4 text-green-600" />
            <span>Chennai, India</span>
          </div>
          <div className="flex items-center gap-2">
            <Calendar className="w-4 h-4 text-green-600" />
            <span>Member since Aug 2025</span>
          </div>
        </div>
      </div>

      <div className="relative flex items-center gap-8 bg-white/70 backdrop-blur rounded-xl px-8 py-4">
        <div className="text-center">
          <Leaf className="w-4 h-4 text-green-600 mx-auto mb-1" />
          <div className="text-xl font-bold text-gray-900">250</div>
          <div className="text-xs text-gray-500">Points</div>
        </div>
        <div className="text-center">
          <Recycle className="w-4 h-4 text-green-600 mx-auto mb-1" />
          <div className="text-xl font-bold text-gray-900">18</div>
          <div className="text-xs text-gray-500">Reports</div>
        </div>
        <div className="text-center">
          <Trophy className="w-4 h-4 text-amber-500 mx-auto mb-1" />
          <div className="text-xl font-bold text-gray-900">5</div>
          <div className="text-xs text-gray-500">Rank</div>
        </div>
      </div>
    </div>
  );
}

function FeatureCard({ feature, onClick }) {
  const Icon = feature.icon;
  return (
    <div className="bg-white border border-gray-100 rounded-2xl p-5 shadow-sm flex flex-col">
      <div className="flex items-start justify-between mb-3">
        <div className={`w-14 h-14 rounded-full ${feature.iconBg} flex items-center justify-center`}>
          <Icon className={`w-6 h-6 ${feature.iconColor}`} />
        </div>
        <span className="text-xs font-bold text-gray-300">{feature.n}</span>
      </div>
      <h4 className={`font-bold ${feature.titleColor} leading-snug`}>{feature.title}</h4>
      <p className="text-xs text-gray-400 mt-2 mb-4 flex-1">{feature.desc}</p>
      <button
        onClick={onClick}
        className={`${feature.btnBg} text-white text-sm font-semibold rounded-lg py-2.5 transition-colors`}
      >
        {feature.btnLabel}
      </button>
    </div>
  );
}

function StatsBar() {
  return (
    <div className="bg-white border border-gray-100 rounded-2xl px-8 py-6 flex items-center justify-between mt-6">
      {STATS.map((s, i) => (
        <div key={i} className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-full bg-gray-50 flex items-center justify-center">
            {s.icon === "co2" ? (
              <span className={`text-xs font-bold ${s.iconColor}`}>CO₂</span>
            ) : (
              <s.icon className={`w-4 h-4 ${s.iconColor}`} />
            )}
          </div>
          <div>
            <div className="text-lg font-bold text-gray-900 leading-none">{s.value}</div>
            <div className="text-xs text-gray-400 mt-1">{s.label}</div>
          </div>
        </div>
      ))}
    </div>
  );
}

function RecentActivity() {
  return (
    <aside className="w-80 shrink-0 pl-6">
      <div className="bg-white border border-gray-100 rounded-2xl p-5 shadow-sm">
        <h3 className="font-bold text-gray-900">Recent Activity</h3>
        <div className="w-8 h-0.5 bg-green-500 mt-1 mb-4 rounded-full" />
        <div className="space-y-4">
          {ACTIVITY.map((a, i) => {
            const Icon = a.icon;
            return (
              <div key={i} className="flex items-start gap-3">
                <div className={`w-9 h-9 rounded-full ${a.iconBg} flex items-center justify-center shrink-0`}>
                  <Icon className={`w-4 h-4 ${a.iconColor}`} />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm text-gray-700 leading-snug">{a.text}</p>
                  <p className="text-xs text-gray-400 mt-0.5">{a.time}</p>
                </div>
                <span className="text-xs font-semibold text-green-600 whitespace-nowrap">{a.pts}</span>
              </div>
            );
          })}
        </div>
      </div>

      <div className="relative overflow-hidden bg-green-50 rounded-2xl p-5 mt-6">
        <Leaf className="w-5 h-5 text-green-600 mb-3" />
        <p className="font-bold text-gray-900">Every action counts.</p>
        <p className="text-sm text-gray-600 mt-1">Thank you for making a difference!</p>
        <Recycle className="w-16 h-16 text-green-200 absolute -bottom-3 -right-3" />
      </div>
    </aside>
  );
}

function Footer() {
  return (
    <div className="bg-green-800 text-white text-sm px-8 py-3 flex items-center justify-between mt-8 rounded-2xl">
      <div className="flex items-center gap-2">
        <Globe className="w-4 h-4" />
        <span>Together for a cleaner planet.</span>
      </div>
      <span className="text-green-100">© 2025 EcoDetect. All rights reserved.</span>
    </div>
  );
}

function HomePage({ name, onFeatureClick }) {
  return (
    <>
      <TopBar name={name} />
      <ProfileCard name={name} />

      <div className="mt-8">
        <h3 className="font-bold text-gray-900">Explore Features</h3>
        <div className="w-8 h-0.5 bg-green-500 mt-1 mb-4 rounded-full" />
        <div className="grid grid-cols-4 gap-5">
          {FEATURES.map((f) => (
            <FeatureCard key={f.n} feature={f} onClick={() => onFeatureClick(f.tab)} />
          ))}
        </div>
      </div>

      <StatsBar />
      <Footer />
    </>
  );
}

function EmptyPage({ item }) {
  const Icon = item.icon;
  return (
    <div className="flex flex-col items-center justify-center text-center py-32">
      <div className="w-16 h-16 rounded-full bg-green-50 flex items-center justify-center mb-4">
        <Icon className="w-7 h-7 text-green-600" />
      </div>
      <h2 className="text-xl font-bold text-gray-900">{item.label}</h2>
      <p className="text-gray-400 text-sm mt-2 max-w-sm">
        This page is empty for now. We'll build out {item.label.toLowerCase()} next.
      </p>
    </div>
  );
}

export default function App() {
  const [active, setActive] = useState("home");
  const name = "Bhuvaneshkanth";
  const activeItem = NAV_ITEMS.find((i) => i.id === active);

  return (
    <div className="min-h-screen bg-gray-50 flex font-sans">
      <Sidebar active={active} onSelect={setActive} />
      <main className="flex-1 flex px-8 py-6">
        <div className="flex-1 min-w-0">
          {active === "home" ? (
            <HomePage name={name} onFeatureClick={setActive} />
          ) : (
            <>
              <TopBar name={name} />
              <EmptyPage item={activeItem} />
            </>
          )}
        </div>
        {active === "home" && <RecentActivity />}
      </main>
    </div>
  );
}
