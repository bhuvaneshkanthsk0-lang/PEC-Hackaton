import React, { useState, useRef, useEffect } from "react";
import {
  Home,
  ShoppingBag,
  ScanLine,
  Recycle,
  FileText,
  Heart,
  Trophy,
  Clock,
  User,
  Settings,
  HelpCircle,
  Bell,
  ChevronDown,
  Star,
  MapPin,
  Calendar,
  Leaf,
  Camera,
  Wind,
  MapPinned,
  Gift,
  Globe,
  Award,
  CheckCircle,
} from "lucide-react";

const NAV_ITEMS = [
  { id: "home", label: "Home", icon: Home },
  { id: "store", label: "Store", icon: ShoppingBag },
  { id: "detect", label: "AI Waste Detection", icon: ScanLine },
  { id: "recycle", label: "Recycle Value", icon: Recycle },
  { id: "reporting", label: "Smart Reporting", icon: FileText },
  { id: "rewards", label: "Rewards", icon: Heart },
  { id: "leaderboard", label: "Leaderboard", icon: Trophy },
  { id: "history", label: "History", icon: Clock },
  { id: "profile", label: "Profile", icon: User },
  { id: "settings", label: "Settings", icon: Settings },
  { id: "help", label: "Help & Support", icon: HelpCircle },
];

const FEATURES = [
  {
    n: "01",
    icon: ScanLine,
    iconBg: "bg-blue-100",
    iconColor: "text-blue-500",
    title: "AI Waste Detection",
    titleColor: "text-blue-600",
    desc: "Identify waste type instantly using a photo.",
    btnBg: "bg-blue-500 hover:bg-blue-600",
    btnLabel: "Detect Now",
    tab: "detect",
  },
  {
    n: "02",
    icon: Recycle,
    iconBg: "bg-green-100",
    iconColor: "text-green-600",
    title: "Recycling Value Estimation",
    titleColor: "text-green-700",
    desc: "Display the estimated recycling/scrap value.",
    btnBg: "bg-green-600 hover:bg-green-700",
    btnLabel: "Check Value",
    tab: "recycle",
  },
  {
    n: "03",
    icon: MapPinned,
    iconBg: "bg-orange-100",
    iconColor: "text-orange-500",
    title: "Smart Waste Reporting",
    titleColor: "text-orange-500",
    desc: "Report public waste with photo and GPS location.",
    btnBg: "bg-orange-500 hover:bg-orange-600",
    btnLabel: "Report Now",
    tab: "reporting",
  },
  {
    n: "04",
    icon: Gift,
    iconBg: "bg-purple-100",
    iconColor: "text-purple-500",
    title: "Reward & Leaderboard",
    titleColor: "text-purple-600",
    desc: "Earn points for verified reports and recycling.",
    btnBg: "bg-purple-500 hover:bg-purple-600",
    btnLabel: "View Leaderboard",
    tab: "leaderboard",
  },
];

const ACTIVITY = [
  {
    icon: Recycle,
    iconBg: "bg-green-100",
    iconColor: "text-green-600",
    text: "You scanned Plastic Bottle",
    time: "2 hrs ago",
    pts: "+10 pts",
  },
  {
    icon: MapPin,
    iconBg: "bg-red-100",
    iconColor: "text-red-500",
    text: "You reported illegal waste",
    time: "1 day ago",
    pts: "+15 pts",
  },
  {
    icon: Recycle,
    iconBg: "bg-green-100",
    iconColor: "text-green-600",
    text: "You recycled 2 kg Plastic",
    time: "2 days ago",
    pts: "+20 pts",
  },
  {
    icon: Gift,
    iconBg: "bg-red-100",
    iconColor: "text-red-500",
    text: 'You earned "Eco Champion" badge',
    time: "3 days ago",
    pts: "+25 pts",
  },
];

const STATS = [
  { icon: Leaf, iconColor: "text-green-600", value: "128", label: "Waste Detected" },
  { icon: Recycle, iconColor: "text-green-600", value: "56 kg", label: "Waste Recycled" },
  { icon: "co2", iconColor: "text-sky-500", value: "210 kg", label: "CO₂ Saved" },
  { icon: User, iconColor: "text-green-600", value: "342", label: "Active Users" },
];

const STORE_ITEMS = [
  { id: 1, title: "Eco-Friendly Bamboo Toothbrush", cost: 50, category: "Sustainable Living", emoji: "🦷" },
  { id: 2, title: "Reusable Stainless Steel Water Bottle", cost: 120, category: "Zero Waste", emoji: "🍼" },
  { id: 3, title: "100% Organic Cotton Tote Bag", cost: 90, category: "Accessories", emoji: "🛍️" },
  { id: 4, title: "Biodegradable Phone Case", cost: 150, category: "Tech", emoji: "📱" },
  { id: 5, title: "Plantable Seed Paper Notebook", cost: 75, category: "Stationery", emoji: "📓" },
  { id: 6, title: "Solar-Powered USB Power Bank", cost: 300, category: "Electronics", emoji: "☀️" },
];

function Sidebar({ active, onSelect }) {
  return (
    <aside className="w-64 shrink-0 bg-white border-r border-gray-100 flex flex-col h-screen sticky top-0">
      <div className="flex items-center gap-3 px-6 pt-6 pb-5">
        <div className="w-11 h-11 rounded-full bg-gradient-to-br from-green-400 to-green-600 flex items-center justify-center">
          <Recycle className="w-6 h-6 text-white" />
        </div>
        <div>
          <div className="text-lg font-bold text-gray-900 leading-tight">EcoDetect</div>
          <div className="text-[11px] text-gray-400 leading-tight">Detect. Report. Recycle. Reward.</div>
        </div>
      </div>

      <nav className="flex-1 px-3 space-y-1 overflow-y-auto">
        {NAV_ITEMS.map((item) => {
          const Icon = item.icon;
          const isActive = active === item.id;
          return (
            <button
              key={item.id}
              onClick={() => onSelect(item.id)}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors ${
                isActive
                  ? "bg-green-50 text-green-700"
                  : "text-gray-600 hover:bg-gray-50"
              }`}
            >
              <Icon className={`w-[18px] h-[18px] ${isActive ? "text-green-700" : "text-gray-400"}`} />
              <span>{item.label}</span>
            </button>
          );
        })}
      </nav>

      <div className="p-4">
        <div className="relative overflow-hidden rounded-2xl bg-green-50 p-5">
          <div className="relative z-10">
            <p className="text-sm font-bold text-gray-900 leading-snug">
              Small actions, big impact.
            </p>
            <p className="text-xs text-gray-500 mt-1">Be a part of the solution.</p>
          </div>
          <div className="mt-6 flex items-end justify-center gap-2 h-14">
            <div className="w-5 h-8 bg-green-300 rounded-t-full" />
            <div className="w-5 h-12 bg-green-400 rounded-t-full" />
            <Wind className="w-6 h-6 text-green-500 mb-1" />
            <div className="w-5 h-10 bg-green-300 rounded-t-full" />
          </div>
        </div>
      </div>
    </aside>
  );
}

function TopBar({ name, credits }) {
  return (
    <div className="flex items-start justify-between mb-6">
      <div>
        <h1 className="text-2xl font-bold text-gray-900">Welcome back,</h1>
        <h2 className="text-2xl font-bold text-green-600 flex items-center gap-2">
          {name} <Leaf className="w-5 h-5 text-green-500" />
        </h2>
        <p className="text-gray-400 text-sm mt-1">
          Together, let's build a cleaner and greener tomorrow.
        </p>
      </div>
      <div className="flex items-center gap-3">
        <div className="flex items-center gap-1.5 bg-white border border-gray-200 rounded-full px-4 py-2 text-sm font-semibold text-gray-700 shadow-sm">
          <Star className="w-4 h-4 text-amber-400 fill-amber-400" />
          Credits <span className="text-gray-900">{credits}</span>
        </div>
        <button className="relative w-10 h-10 rounded-full bg-white border border-gray-200 flex items-center justify-center shadow-sm">
          <Bell className="w-[18px] h-[18px] text-gray-500" />
          <span className="absolute top-2 right-2.5 w-1.5 h-1.5 bg-green-500 rounded-full" />
        </button>
        <div className="w-10 h-10 rounded-full bg-gray-200 flex items-center justify-center overflow-hidden">
          <User className="w-5 h-5 text-gray-400" />
        </div>
        <ChevronDown className="w-4 h-4 text-gray-400" />
      </div>
    </div>
  );
}

function ProfileCard({ name }) {
  return (
    <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-green-50 to-green-100 p-6 flex items-center gap-6">
      <div className="absolute inset-0 flex items-end justify-end opacity-70 pointer-events-none">
        <div className="flex items-end gap-1 pr-6 pb-0">
          <div className="w-8 h-16 bg-green-200 rounded-t-md" />
          <div className="w-8 h-24 bg-green-300 rounded-t-md" />
          <div className="w-8 h-14 bg-green-200 rounded-t-md" />
          <Wind className="w-10 h-10 text-green-400 mb-2" />
          <Wind className="w-8 h-8 text-green-300 mb-6" />
        </div>
      </div>

      <div className="relative shrink-0">
        <div className="w-24 h-24 rounded-full bg-gradient-to-br from-green-500 to-green-700 flex items-center justify-center">
          <Leaf className="w-10 h-10 text-white" />
        </div>
        <div className="absolute -bottom-1 -right-1 w-8 h-8 rounded-full bg-gray-900 flex items-center justify-center border-2 border-white">
          <Camera className="w-4 h-4 text-white" />
        </div>
      </div>

      <div className="relative flex-1 min-w-[220px]">
        <h3 className="text-xl font-bold text-gray-900">{name}</h3>
        <div className="mt-2 space-y-1.5 text-sm text-gray-600">
          <div className="flex items-center gap-2">
            <Award className="w-4 h-4 text-green-600" />
            <span>Eco Warrior</span>
          </div>
          <div className="flex items-center gap-2">
            <MapPin className="w-4 h-4 text-green-600" />
            <span>Chennai, India</span>
          </div>
          <div className="flex items-center gap-2">
            <Calendar className="w-4 h-4 text-green-600" />
            <span>Member since Aug 2025</span>
          </div>
        </div>
      </div>

      <div className="relative flex items-center gap-8 bg-white/70 backdrop-blur rounded-xl px-8 py-4">
        <div className="text-center">
          <Leaf className="w-4 h-4 text-green-600 mx-auto mb-1" />
          <div className="text-xl font-bold text-gray-900">250</div>
          <div className="text-xs text-gray-500">Points</div>
        </div>
        <div className="text-center">
          <Recycle className="w-4 h-4 text-green-600 mx-auto mb-1" />
          <div className="text-xl font-bold text-gray-900">18</div>
          <div className="text-xs text-gray-500">Reports</div>
        </div>
        <div className="text-center">
          <Trophy className="w-4 h-4 text-amber-500 mx-auto mb-1" />
          <div className="text-xl font-bold text-gray-900">5</div>
          <div className="text-xs text-gray-500">Rank</div>
        </div>
      </div>
    </div>
  );
}

function FeatureCard({ feature, onClick }) {
  const Icon = feature.icon;
  return (
    <div className="bg-white border border-gray-100 rounded-2xl p-5 shadow-sm flex flex-col">
      <div className="flex items-start justify-between mb-3">
        <div className={`w-14 h-14 rounded-full ${feature.iconBg} flex items-center justify-center`}>
          <Icon className={`w-6 h-6 ${feature.iconColor}`} />
        </div>
        <span className="text-xs font-bold text-gray-300">{feature.n}</span>
      </div>
      <h4 className={`font-bold ${feature.titleColor} leading-snug`}>{feature.title}</h4>
      <p className="text-xs text-gray-400 mt-2 mb-4 flex-1">{feature.desc}</p>
      <button
        onClick={onClick}
        className={`${feature.btnBg} text-white text-sm font-semibold rounded-lg py-2.5 transition-colors`}
      >
        {feature.btnLabel}
      </button>
    </div>
  );
}

function StatsBar() {
  return (
    <div className="bg-white border border-gray-100 rounded-2xl px-8 py-6 flex items-center justify-between mt-6">
      {STATS.map((s, i) => (
        <div key={i} className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-full bg-gray-50 flex items-center justify-center">
            {s.icon === "co2" ? (
              <span className={`text-xs font-bold ${s.iconColor}`}>CO₂</span>
            ) : (
              <s.icon className={`w-4 h-4 ${s.iconColor}`} />
            )}
          </div>
          <div>
            <div className="text-lg font-bold text-gray-900 leading-none">{s.value}</div>
            <div className="text-xs text-gray-400 mt-1">{s.label}</div>
          </div>
        </div>
      ))}
    </div>
  );
}

function RecentActivity() {
  return (
    <aside className="w-80 shrink-0 pl-6">
      <div className="bg-white border border-gray-100 rounded-2xl p-5 shadow-sm">
        <h3 className="font-bold text-gray-900">Recent Activity</h3>
        <div className="w-8 h-0.5 bg-green-500 mt-1 mb-4 rounded-full" />
        <div className="space-y-4">
          {ACTIVITY.map((a, i) => {
            const Icon = a.icon;
            return (
              <div key={i} className="flex items-start gap-3">
                <div className={`w-9 h-9 rounded-full ${a.iconBg} flex items-center justify-center shrink-0`}>
                  <Icon className={`w-4 h-4 ${a.iconColor}`} />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm text-gray-700 leading-snug">{a.text}</p>
                  <p className="text-xs text-gray-400 mt-0.5">{a.time}</p>
                </div>
                <span className="text-xs font-semibold text-green-600 whitespace-nowrap">{a.pts}</span>
              </div>
            );
          })}
        </div>
      </div>

      <div className="relative overflow-hidden bg-green-50 rounded-2xl p-5 mt-6">
        <Leaf className="w-5 h-5 text-green-600 mb-3" />
        <p className="font-bold text-gray-900">Every action counts.</p>
        <p className="text-sm text-gray-600 mt-1">Thank you for making a difference!</p>
        <Recycle className="w-16 h-16 text-green-200 absolute -bottom-3 -right-3" />
      </div>
    </aside>
  );
}

function Footer() {
  return (
    <div className="bg-green-800 text-white text-sm px-8 py-3 flex items-center justify-between mt-8 rounded-2xl">
      <div className="flex items-center gap-2">
        <Globe className="w-4 h-4" />
        <span>Together for a cleaner planet.</span>
      </div>
      <span className="text-green-100">© 2025 EcoDetect. All rights reserved.</span>
    </div>
  );
}

function HomePage({ name, onFeatureClick }) {
  return (
    <>
      <ProfileCard name={name} />

      <div className="mt-8">
        <h3 className="font-bold text-gray-900">Explore Features</h3>
        <div className="w-8 h-0.5 bg-green-500 mt-1 mb-4 rounded-full" />
        <div className="grid grid-cols-4 gap-5">
          {FEATURES.map((f) => (
            <FeatureCard key={f.n} feature={f} onClick={() => onFeatureClick(f.tab)} />
          ))}
        </div>
      </div>

      <StatsBar />
      <Footer />
    </>
  );
}

function DetectionPage({ userName }) {
  const [file, setFile] = useState(null);
  const [preview, setPreview] = useState(null);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState(null);
  const [error, setError] = useState(null);
  
  const [isCameraMode, setIsCameraMode] = useState(false);
  const videoRef = useRef(null);
  const canvasRef = useRef(null);
  const [stream, setStream] = useState(null);

  useEffect(() => {
    return () => {
      if (stream) {
        stream.getTracks().forEach(track => track.stop());
      }
    };
  }, [stream]);

  const startCamera = async () => {
    setError(null);
    setResult(null);
    setPreview(null);
    setFile(null);
    setIsCameraMode(true);
    
    try {
      const mediaStream = await navigator.mediaDevices.getUserMedia({ 
        video: { facingMode: "environment" } 
      });
      setStream(mediaStream);
      if (videoRef.current) {
        videoRef.current.srcObject = mediaStream;
      }
    } catch (err) {
      setError("Camera access denied or unavailable.");
      setIsCameraMode(false);
    }
  };

  const stopCamera = () => {
    if (stream) {
      stream.getTracks().forEach(track => track.stop());
      setStream(null);
    }
    setIsCameraMode(false);
  };

  const captureFrame = () => {
    if (!videoRef.current || !canvasRef.current) return;
    
    const video = videoRef.current;
    const canvas = canvasRef.current;
    
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    const ctx = canvas.getContext('2d');
    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);

    canvas.toBlob((blob) => {
      const capturedFile = new File([blob], "camera_capture.jpg", { type: "image/jpeg" });
      setFile(capturedFile);
      setPreview(URL.createObjectURL(capturedFile));
      stopCamera();
    }, 'image/jpeg');
  };

  const handleFileChange = (e) => {
    const selected = e.target.files[0];
    setFile(selected);
    if (selected) {
      setPreview(URL.createObjectURL(selected));
    }
    setResult(null);
    setError(null);
  };

  const handleDetect = async (e) => {
    e.preventDefault();
    if (!file) return;

    setLoading(true);
    setError(null);

    const formData = new FormData();
    formData.append('image', file);
    formData.append('user_id', userName);

    const sendToAI = async (data) => {
      try {
        const res = await fetch('http://127.0.0.1:5000/detect', {
          method: 'POST',
          body: data,
        });
        const json = await res.json();
        
        if (res.ok && json.status === 'success') {
          setResult(json);
        } else {
          setError(json.error || 'Detection failed on server.');
        }
      } catch (err) {
        setError('Connection Error. Ensure your Flask backend (app.py) is running on port 5000.');
      } finally {
        setLoading(false);
      }
    };

    if ("geolocation" in navigator) {
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          formData.append('latitude', pos.coords.latitude);
          formData.append('longitude', pos.coords.longitude);
          sendToAI(formData);
        },
        () => sendToAI(formData)
      );
    } else {
      sendToAI(formData);
    }
  };

  return (
    <div className="max-w-2xl mx-auto mt-4">
      <div className="bg-white border border-gray-100 rounded-2xl p-8 shadow-sm">
        <div className="text-center mb-6">
          <div className="w-16 h-16 rounded-full bg-blue-50 flex items-center justify-center mx-auto mb-4">
            <ScanLine className="w-7 h-7 text-blue-600" />
          </div>
          <h2 className="text-2xl font-bold text-gray-900">AI Waste Detection</h2>
          <p className="text-gray-500 text-sm mt-2">Use your camera or upload a photo to identify waste and extract scrap value.</p>
        </div>

        <div className="flex gap-4 justify-center mb-6">
          {!isCameraMode && (
            <button 
              onClick={startCamera} 
              className="bg-gray-100 hover:bg-gray-200 text-gray-800 font-semibold py-2 px-6 rounded-lg transition-colors flex items-center gap-2"
            >
              <Camera className="w-5 h-5" /> Open Camera
            </button>
          )}
          {isCameraMode && (
            <button 
              onClick={stopCamera} 
              className="bg-red-50 hover:bg-red-100 text-red-600 font-semibold py-2 px-6 rounded-lg transition-colors flex items-center gap-2"
            >
              Cancel Camera
            </button>
          )}
        </div>

        {isCameraMode ? (
          <div className="flex flex-col items-center border-2 border-gray-200 rounded-xl p-4 bg-black">
            <video 
              ref={videoRef} 
              autoPlay 
              playsInline 
              className="w-full max-h-96 object-contain rounded-lg mb-4"
            ></video>
            <button 
              onClick={captureFrame} 
              className="bg-blue-500 hover:bg-blue-600 text-white font-bold py-3 px-8 rounded-full transition-colors flex items-center gap-2"
            >
              <Camera className="w-5 h-5" /> Capture Photo
            </button>
            <canvas ref={canvasRef} className="hidden"></canvas>
          </div>
        ) : (
          <form onSubmit={handleDetect} className="space-y-6">
            <label className="block w-full border-2 border-dashed border-gray-300 rounded-xl p-8 text-center cursor-pointer hover:bg-gray-50 transition">
              <input type="file" accept="image/*" className="hidden" onChange={handleFileChange} />
              {preview ? (
                <img src={preview} alt="Preview" className="mx-auto h-48 object-contain rounded-lg" />
              ) : (
                <div className="flex flex-col items-center">
                  <div className="w-12 h-12 bg-gray-100 rounded-full flex items-center justify-center mb-3">
                    <ScanLine className="w-6 h-6 text-gray-400" />
                  </div>
                  <span className="text-gray-600 font-medium">Click to upload an image file</span>
                </div>
              )}
            </label>

            <button
              type="submit"
              disabled={!file || loading}
              className="w-full bg-blue-500 hover:bg-blue-600 disabled:bg-blue-300 text-white font-bold py-3.5 rounded-xl transition-colors shadow-sm"
            >
              {loading ? "Analyzing & Locating..." : "Analyze Image"}
            </button>
          </form>
        )}

        {error && (
          <div className="mt-6 p-4 bg-red-50 border border-red-100 text-red-600 rounded-xl text-sm text-center">
            {error}
          </div>
        )}

        {result && (
          <div className="mt-8 bg-gray-50 rounded-xl p-6 border border-gray-100">
            <h3 className="font-bold text-gray-900 mb-4 flex items-center gap-2">
              <ScanLine className="w-5 h-5 text-green-600" />
              Detection Summary
            </h3>
            
            <div className="grid grid-cols-2 gap-4 mb-4">
              <div className="bg-white p-4 rounded-lg border border-gray-100 shadow-sm text-center">
                <div className="text-gray-500 text-xs mb-1">Items Found</div>
                <div className="text-2xl font-bold text-gray-900">{result.total_items}</div>
              </div>
              <div className="bg-white p-4 rounded-lg border border-gray-100 shadow-sm text-center">
                <div className="text-gray-500 text-xs mb-1">Est. Scrap Value</div>
                <div className="text-2xl font-bold text-green-600">₹{result.total_value}</div>
              </div>
            </div>

            {result.detections.length > 0 && (
              <ul className="space-y-2">
                {result.detections.map((item, idx) => (
                  <li key={idx} className="flex justify-between items-center bg-white px-4 py-3 rounded-lg border border-gray-100">
                    <span className="font-medium text-gray-800 capitalize">{item.item}</span>
                    <div className="text-right">
                      <span className="text-xs text-gray-400 mr-3">Conf: {(item.confidence * 100).toFixed(0)}%</span>
                      <span className="font-bold text-green-600">₹{item.estimated_value}</span>
                    </div>
                  </li>
                ))}
              </ul>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

function StorePage({ userCredits, onRedeem }) {
  const [purchasedId, setPurchasedId] = useState(null);

  const handleBuy = (item) => {
    if (userCredits < item.cost) {
      alert("Not enough credits to redeem this item!");
      return;
    }
    setPurchasedId(item.id);
    onRedeem(item.cost);
    setTimeout(() => setPurchasedId(null), 3000);
  };

  return (
    <div className="max-w-4xl mx-auto mt-4">
      <div className="bg-gradient-to-r from-emerald-600 to-teal-700 rounded-2xl p-8 text-white mb-8 shadow-sm flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-extrabold mb-2">Eco Reward Store</h2>
          <p className="text-emerald-100 text-sm max-w-lg">Redeem your verified recycling credits for sustainable goods and green products.</p>
        </div>
        <div className="bg-white/10 backdrop-blur-md px-6 py-4 rounded-2xl border border-white/20 text-center">
          <p className="text-xs text-emerald-100 font-medium">Your Balance</p>
          <p className="text-2xl font-bold flex items-center gap-1 mt-1">
            <Star className="w-5 h-5 text-amber-300 fill-amber-300" /> {userCredits}
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {STORE_ITEMS.map((item) => (
          <div key={item.id} className="bg-white border border-gray-100 rounded-2xl p-6 shadow-sm flex flex-col justify-between transition hover:shadow-md">
            <div>
              <div className="w-16 h-16 bg-emerald-50 rounded-2xl flex items-center justify-center text-3xl mb-4">
                {item.emoji}
              </div>
              <span className="text-xs font-semibold text-emerald-600 uppercase tracking-wider">{item.category}</span>
              <h3 className="text-lg font-bold text-gray-900 mt-1 mb-2">{item.title}</h3>
            </div>

            <div className="pt-4 border-t border-gray-100 flex items-center justify-between mt-4">
              <div className="flex items-center gap-1 font-bold text-gray-900">
                <Star className="w-4 h-4 text-amber-400 fill-amber-400" />
                {item.cost} pts
              </div>
              <button
                onClick={() => handleBuy(item)}
                className={`px-4 py-2 rounded-xl text-sm font-semibold transition-all ${
                  purchasedId === item.id
                    ? "bg-emerald-600 text-white flex items-center gap-1"
                    : "bg-emerald-50 hover:bg-emerald-600 hover:text-white text-emerald-700"
                }`}
              >
                {purchasedId === item.id ? (
                  <>
                    <CheckCircle className="w-4 h-4" /> Redeemed!
                  </>
                ) : (
                  "Redeem Item"
                )}
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function ReportingPage() {
  return (
    <div className="bg-white border border-gray-100 rounded-2xl p-5 shadow-sm h-[700px] flex flex-col">
      <div className="flex items-center gap-3 mb-4">
        <div className="w-10 h-10 rounded-full bg-orange-50 flex items-center justify-center">
          <MapPinned className="w-5 h-5 text-orange-500" />
        </div>
        <div>
          <h3 className="font-bold text-gray-900">Live Authority Map</h3>
          <p className="text-xs text-gray-500">Live reporting and nearby recycling hubs</p>
        </div>
      </div>
      
      <iframe
        src="http://127.0.0.1:5000/map"
        className="w-full flex-1 rounded-xl border border-gray-200"
        title="Live Waste Map"
      />
    </div>
  );
}

function RecycleValuePage() {
  const [summary, setSummary] = useState({ total_items: 0, total_value: 0, history: [] });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch('http://localhost:5000/api/user-summary')
      .then(res => res.json())
      .then(data => {
        setSummary(data);
        setLoading(false);
      })
      .catch(err => {
        console.error("Error fetching summary:", err);
        setLoading(false);
      });
  }, []);

  return (
    <div className="max-w-4xl mx-auto mt-4">
      <div className="grid grid-cols-2 gap-6 mb-8">
        <div className="bg-white border border-gray-100 rounded-2xl p-6 shadow-sm flex items-center justify-between">
          <div>
            <p className="text-xs font-semibold text-gray-400 uppercase tracking-wider">Total Items Recycled</p>
            <h3 className="text-4xl font-extrabold text-gray-900 mt-2">{summary.total_items}</h3>
          </div>
          <div className="w-14 h-14 bg-green-50 text-green-600 rounded-2xl flex items-center justify-center text-2xl font-bold">📦</div>
        </div>

        <div className="bg-white border border-gray-100 rounded-2xl p-6 shadow-sm flex items-center justify-between">
          <div>
            <p className="text-xs font-semibold text-gray-400 uppercase tracking-wider">Total Estimated Value</p>
            <h3 className="text-4xl font-extrabold text-green-600 mt-2">₹{summary.total_value}</h3>
          </div>
          <div className="w-14 h-14 bg-green-50 text-green-600 rounded-2xl flex items-center justify-center text-2xl font-bold">💰</div>
        </div>
      </div>

      <div className="bg-white border border-gray-100 rounded-2xl p-8 shadow-sm">
        <h3 className="text-xl font-bold text-gray-900 mb-6 flex items-center gap-2">
          <Recycle className="w-5 h-5 text-green-600" />
          Recycling History
        </h3>
        {loading ? (
          <p className="text-gray-400 text-center py-8">Loading history...</p>
        ) : summary.history.length === 0 ? (
          <p className="text-gray-400 text-center py-8">No items scanned yet. Head over to AI Waste Detection to start scanning!</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-gray-100 text-gray-400 text-xs uppercase tracking-wider">
                  <th className="pb-3 font-semibold">Item Type</th>
                  <th className="pb-3 font-semibold">Est. Value</th>
                  <th className="pb-3 font-semibold">Timestamp</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-50 text-sm">
                {summary.history.map((item, index) => (
                  <tr key={index} className="hover:bg-gray-50/50 transition-colors">
                    <td className="py-4 font-semibold text-gray-800 capitalize">{item.item_type}</td>
                    <td className="py-4 font-bold text-green-600">₹{item.estimated_value}</td>
                    <td className="py-4 text-gray-400">{item.timestamp}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}

function RewardsPage({ userCredits }) {
  const badges = [
    { id: 1, title: "Eco Champion", req: 100, desc: "Reached 100 recycling points", icon: "🌱", unlocked: true },
    { id: 2, title: "Plastic Master", req: 250, desc: "Recycled 25+ plastic items", icon: "♻️", unlocked: userCredits >= 250 },
    { id: 3, title: "Green Guardian", req: 500, desc: "Saved over 50kg of CO₂ emissions", icon: "🌍", unlocked: userCredits >= 500 },
    { id: 4, title: "Zero Waste Hero", req: 1000, desc: "Reached 1000 total platform points", icon: "🏆", unlocked: userCredits >= 1000 },
  ];

  return (
    <div className="max-w-4xl mx-auto mt-4">
      <div className="bg-gradient-to-r from-purple-600 to-indigo-700 rounded-2xl p-8 text-white mb-8 shadow-sm flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-extrabold mb-2">Milestones & Rewards</h2>
          <p className="text-purple-100 text-sm max-w-lg">Unlock achievement badges and level up your eco status as you recycle more.</p>
        </div>
        <div className="bg-white/10 backdrop-blur-md px-6 py-4 rounded-2xl border border-white/20 text-center">
          <p className="text-xs text-purple-100 font-medium">Available Points</p>
          <p className="text-2xl font-bold flex items-center gap-1 mt-1">
            <Star className="w-5 h-5 text-amber-300 fill-amber-300" /> {userCredits}
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {badges.map((b) => (
          <div key={b.id} className={`bg-white border rounded-2xl p-6 shadow-sm flex items-center gap-5 transition ${b.unlocked ? 'border-purple-200 bg-purple-50/10' : 'border-gray-100 opacity-75'}`}>
            <div className={`w-16 h-16 rounded-2xl flex items-center justify-center text-3xl shrink-0 ${b.unlocked ? 'bg-purple-100' : 'bg-gray-100'}`}>
              {b.icon}
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between mb-1">
                <h3 className="text-lg font-bold text-gray-900 truncate">{b.title}</h3>
                <span className={`text-xs font-semibold px-2.5 py-1 rounded-full ${b.unlocked ? 'bg-purple-100 text-purple-700' : 'bg-gray-100 text-gray-500'}`}>
                  {b.req} pts
                </span>
              </div>
              <p className="text-xs text-gray-500 mb-3">{b.desc}</p>
              <div className="flex items-center gap-2">
                {b.unlocked ? (
                  <span className="text-xs font-bold text-purple-600 flex items-center gap-1">
                    <CheckCircle className="w-3.5 h-3.5" /> Badge Unlocked
                  </span>
                ) : (
                  <span className="text-xs text-gray-400">Locked ({b.req - userCredits} pts needed)</span>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function LeaderboardPage() {
  const leaderboardUsers = [
    { rank: 1, name: "Priya Sharma", points: 1450, recycled: "142 kg", badge: "👑" },
    { rank: 2, name: "Rahul Verma", points: 1280, recycled: "115 kg", badge: "🥈" },
    { rank: 3, name: "Ananya Gupta", points: 1100, recycled: "98 kg", badge: "🥉" },
    { rank: 4, name: "Vikram Malhotra", points: 950, recycled: "84 kg", badge: "⭐" },
    { rank: 5, name: "Bhuvaneshkanth", points: 250, recycled: "56 kg", badge: "🍃" },
    { rank: 6, name: "Kavitha Nair", points: 210, recycled: "45 kg", badge: "🌿" },
  ];

  return (
    <div className="max-w-4xl mx-auto mt-4">
      <div className="bg-gradient-to-r from-amber-500 to-orange-600 rounded-2xl p-8 text-white mb-8 shadow-sm flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-extrabold mb-2">Community Leaderboard</h2>
          <p className="text-amber-100 text-sm max-w-lg">See how you rank against top environmental contributors across the region.</p>
        </div>
        <div className="bg-white/10 backdrop-blur-md px-6 py-4 rounded-2xl border border-white/20 text-center">
          <p className="text-xs text-amber-100 font-medium">Your Global Rank</p>
          <p className="text-3xl font-extrabold flex items-center gap-1 mt-1 justify-center">
            🏆 #5
          </p>
        </div>
      </div>

      <div className="bg-white border border-gray-100 rounded-2xl p-8 shadow-sm">
        <h3 className="text-xl font-bold text-gray-900 mb-6 flex items-center gap-2">
          <Trophy className="w-5 h-5 text-amber-500" /> Top Eco Champions
        </h3>
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-gray-100 text-gray-400 text-xs uppercase tracking-wider">
                <th className="pb-3 font-semibold">Rank</th>
                <th className="pb-3 font-semibold">User</th>
                <th className="pb-3 font-semibold">Recycled Weight</th>
                <th className="pb-3 font-semibold text-right">Total Points</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-50 text-sm">
              {leaderboardUsers.map((user) => (
                <tr key={user.rank} className={`hover:bg-gray-50/50 transition-colors ${user.name === "Bhuvaneshkanth" ? "bg-green-50/60 font-semibold" : ""}`}>
                  <td className="py-4 font-bold text-gray-700 flex items-center gap-2">
                    <span className="w-8 h-8 rounded-full bg-gray-100 flex items-center justify-center text-xs">
                      {user.badge} #{user.rank}
                    </span>
                  </td>
                  <td className="py-4 text-gray-900 flex items-center gap-2">
                    {user.name} {user.name === "Bhuvaneshkanth" && <span className="text-xs bg-green-100 text-green-700 px-2 py-0.5 rounded-full font-medium">You</span>}
                  </td>
                  <td className="py-4 text-gray-600">{user.recycled}</td>
                  <td className="py-4 text-right font-bold text-amber-600 flex items-center justify-end gap-1">
                    <Star className="w-4 h-4 fill-amber-400 text-amber-400" /> {user.points} pts
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

function EmptyPage({ item }) {
  const Icon = item.icon;
  return (
    <div className="flex flex-col items-center justify-center text-center py-32">
      <div className="w-16 h-16 rounded-full bg-green-50 flex items-center justify-center mb-4">
        <Icon className="w-7 h-7 text-green-600" />
      </div>
      <h2 className="text-xl font-bold text-gray-900">{item.label}</h2>
      <p className="text-gray-400 text-sm mt-2 max-w-sm">
        This page is empty for now. We'll build out {item.label.toLowerCase()} next.
      </p>
    </div>
  );
}

export default function App() {
  const [active, setActive] = useState("home");
  const [userCredits, setUserCredits] = useState(120);
  const name = "Bhuvaneshkanth";
  const activeItem = NAV_ITEMS.find((i) => i.id === active);

  const handleRedeemPoints = (cost) => {
    setUserCredits((prev) => Math.max(0, prev - cost));
  };

  return (
    <div className="min-h-screen bg-gray-50 flex font-sans">
      <Sidebar active={active} onSelect={setActive} />
      <main className="flex-1 flex px-8 py-6">
        <div className="flex-1 min-w-0">
          <TopBar name={name} credits={userCredits} />
          
          {/* Main Routing Logic */}
          {active === "home" ? (
            <HomePage name={name} onFeatureClick={setActive} />
          ) : active === "detect" ? (
            <DetectionPage userName={name} />
          ) : active === "store" ? (
            <StorePage userCredits={userCredits} onRedeem={handleRedeemPoints} />
          ) : active === "recycle" ? (
            <RecycleValuePage />
          ) : active === "reporting" ? (
            <ReportingPage />
          ) : active === "rewards" ? (
            <RewardsPage userCredits={userCredits} />
          ) : active === "leaderboard" ? (
            <LeaderboardPage />
          ) : (
            <EmptyPage item={activeItem} />
          )}

        </div>
        
        {/* Only show recent activity sidebar on Home */}
        {active === "home" && <RecentActivity />}
      </main>
    </div>
  );
}