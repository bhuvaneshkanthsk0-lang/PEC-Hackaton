import React, { useState, useEffect } from 'react';

export default function RecycleValue() {
    const [summary, setSummary] = useState({ total_items: 0, total_value: 0, history: [] });
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        fetch('http://localhost:5000/api/user-summary')
            .then(res => res.json())
            .then(data => {
                setSummary(data);
                setLoading(false);
            })
            .catch(err => {
                console.error("Error fetching summary:", err);
                setLoading(false);
            });
    }, []);

    return (
        <div className="p-8 max-w-6xl mx-auto text-slate-800">
            <h1 className="text-3xl font-bold mb-2">Recycle Value Dashboard</h1>
            <p className="text-slate-500 mb-8">Track your total recycled items and cumulative earnings in INR.</p>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
                <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 flex items-center justify-between">
                    <div>
                        <p className="text-sm font-medium text-slate-500">Total Items Recycled</p>
                        <h3 className="text-4xl font-extrabold text-slate-900 mt-1">{summary.total_items}</h3>
                    </div>
                    <div className="p-4 bg-emerald-50 text-emerald-600 rounded-xl text-2xl">📦</div>
                </div>

                <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 flex items-center justify-between">
                    <div>
                        <p className="text-sm font-medium text-slate-500">Total Estimated Value</p>
                        <h3 className="text-4xl font-extrabold text-emerald-600 mt-1">₹{summary.total_value}</h3>
                    </div>
                    <div className="p-4 bg-emerald-50 text-emerald-600 rounded-xl text-2xl">💰</div>
                </div>
            </div>

            <div className="bg-white rounded-2xl shadow-sm border border-slate-100 p-6">
                <h3 className="text-xl font-bold mb-4">Recycling History</h3>
                {loading ? (
                    <p className="text-slate-400">Loading history...</p>
                ) : summary.history.length === 0 ? (
                    <p className="text-slate-400 py-4">No items scanned yet. Head over to AI Waste Detection to start scanning!</p>
                ) : (
                    <div className="overflow-x-auto">
                        <table className="w-full text-left border-collapse">
                            <thead>
                                <tr className="border-b border-slate-100 text-slate-400 text-sm">
                                    <th className="pb-3 font-medium">Item Type</th>
                                    <th className="pb-3 font-medium">Est. Value</th>
                                    <th className="pb-3 font-medium">Timestamp</th>
                                </tr>
                            </thead>
                            <tbody className="divide-y divide-slate-50 text-sm">
                                {summary.history.map((item, index) => (
                                    <tr key={index} className="hover:bg-slate-50/50">
                                        <td className="py-3 font-semibold capitalize text-slate-700">{item.item_type}</td>
                                        <td className="py-3 font-bold text-emerald-600">₹{item.estimated_value}</td>
                                        <td className="py-3 text-slate-400">{item.timestamp}</td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                )}
            </div>
        </div>
    );
}