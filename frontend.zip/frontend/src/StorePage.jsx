import React, { useState } from 'react';
import { ShoppingBag, Star, CheckCircle } from 'lucide-react';

const STORE_ITEMS = [
    { id: 1, title: "Eco-Friendly Bamboo Toothbrush", cost: 50, category: "Sustainable Living", emoji: "🦷" },
    { id: 2, title: "Reusable Stainless Steel Water Bottle", cost: 120, category: "Zero Waste", emoji: "🍼" },
    { id: 3, title: "100% Organic Cotton Tote Bag", cost: 90, category: "Accessories", emoji: "🛍️" },
    { id: 4, title: "Biodegradable Phone Case", cost: 150, category: "Tech", emoji: "📱" },
    { id: 5, title: "Plantable Seed Paper Notebook", cost: 75, category: "Stationery", emoji: "📓" },
    { id: 6, title: "Solar-Powered USB Power Bank", cost: 300, category: "Electronics", emoji: "☀️" },
];

export default function StorePage({ userCredits, onRedeem }) {
    const [purchasedId, setPurchasedId] = useState(null);

    const handleBuy = (item) => {
        if (userCredits < item.cost) {
            alert("Not enough credits to redeem this item!");
            return;
        }
        setPurchasedId(item.id);
        onRedeem(item.cost);
        setTimeout(() => setPurchasedId(null), 3000);
    };

    return (
        <div className="max-w-5xl mx-auto mt-4">
            <div className="bg-gradient-to-r from-emerald-600 to-teal-700 rounded-2xl p-8 text-white mb-8 shadow-sm flex items-center justify-between">
                <div>
                    <h2 className="text-3xl font-extrabold mb-2">Eco Reward Store</h2>
                    <p className="text-emerald-100 text-sm max-w-lg">Redeem your verified recycling credits for sustainable goods and green products.</p>
                </div>
                <div className="bg-white/10 backdrop-blur-md px-6 py-4 rounded-2xl border border-white/20 text-center">
                    <p className="text-xs text-emerald-100 font-medium">Your Balance</p>
                    <p className="text-2xl font-bold flex items-center gap-1 mt-1">
                        <Star className="w-5 h-5 text-amber-300 fill-amber-300" /> {userCredits}
                    </p>
                </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {STORE_ITEMS.map((item) => (
                    <div key={item.id} className="bg-white border border-gray-100 rounded-2xl p-6 shadow-sm flex flex-col justify-between transition hover:shadow-md">
                        <div>
                            <div className="w-16 h-16 bg-emerald-50 rounded-2xl flex items-center justify-center text-3xl mb-4">
                                {item.emoji}
                            </div>
                            <span className="text-xs font-semibold text-emerald-600 uppercase tracking-wider">{item.category}</span>
                            <h3 className="text-lg font-bold text-gray-900 mt-1 mb-2">{item.title}</h3>
                        </div>

                        <div className="pt-4 border-t border-gray-100 flex items-center justify-between mt-4">
                            <div className="flex items-center gap-1 font-bold text-gray-900">
                                <Star className="w-4 h-4 text-amber-400 fill-amber-400" />
                                {item.cost} pts
                            </div>
                            <button
                                onClick={() => handleBuy(item)}
                                className={`px-4 py-2 rounded-xl text-sm font-semibold transition-all ${
                                    purchasedId === item.id
                                        ? "bg-emerald-600 text-white flex items-center gap-1"
                                        : "bg-emerald-50 hover:bg-emerald-600 hover:text-white text-emerald-700"
                                }`}
                            >
                                {purchasedId === item.id ? (
                                    <>
                                        <CheckCircle className="w-4 h-4" /> Redeemed!
                                    </>
                                ) : (
                                    "Redeem Item"
                                )}
                            </button>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
}