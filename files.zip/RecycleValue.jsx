import { useEffect, useState } from "react";
import { Recycle, MapPin, CheckCircle2 } from "lucide-react";
import { api } from "../lib/api";

export default function RecycleValue({ params }) {
  const wasteType = params?.wasteType || "Plastic Bottle";
  const [rate, setRate] = useState(null);
  const [logged, setLogged] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    api
      .recycleValue(wasteType)
      .then((data) => !cancelled && setRate(data))
      .catch(() => !cancelled && setRate({ waste_type: wasteType, min_rate: 8, max_rate: 15, unit: "kg" }))
      .finally(() => !cancelled && setLoading(false));
    return () => {
      cancelled = true;
    };
  }, [wasteType]);

  const logRecycled = async () => {
    try {
      await api.recycleLog(params?.scanId);
    } catch {
      /* demo mode — ignore */
    }
    setLogged(true);
  };

  return (
    <div className="max-w-xl mx-auto py-8 px-4">
      <h1 className="text-2xl font-bold text-gray-800 mb-1">Recycle Value</h1>
      <p className="text-gray-500 mb-6">Estimated scrap value for your item</p>

      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-12 h-12 rounded-xl bg-green-100 flex items-center justify-center">
            <Recycle className="w-6 h-6 text-green-600" />
          </div>
          <div>
            <p className="text-gray-800 font-semibold">{wasteType}</p>
            <p className="text-sm text-gray-500">Material category</p>
          </div>
        </div>

        {loading ? (
          <div className="h-20 rounded-xl bg-gray-100 animate-pulse" />
        ) : (
          <div className="bg-gradient-to-br from-green-600 to-green-700 rounded-xl p-5 text-white mb-5">
            <p className="text-green-100 text-sm mb-1">Estimated Value</p>
            <p className="text-3xl font-bold">
              ₹{rate?.min_rate}–₹{rate?.max_rate}
              <span className="text-lg font-normal"> / {rate?.unit || "kg"}</span>
            </p>
          </div>
        )}

        {!logged ? (
          <button
            onClick={logRecycled}
            className="w-full flex items-center justify-center gap-2 bg-green-600 hover:bg-green-700 text-white py-2.5 rounded-lg font-medium transition mb-3"
          >
            <CheckCircle2 className="w-4 h-4" /> Log as Recycled (+10 pts)
          </button>
        ) : (
          <div className="flex items-center justify-center gap-2 text-green-700 bg-green-50 border border-green-100 rounded-lg py-2.5 mb-3 font-medium">
            <CheckCircle2 className="w-4 h-4" /> Logged! +10 points earned
          </div>
        )}

        <button className="w-full flex items-center justify-center gap-2 border border-gray-200 hover:bg-gray-50 text-gray-700 py-2.5 rounded-lg font-medium transition">
          <MapPin className="w-4 h-4" /> Find Nearby Recycling Centers
        </button>
      </div>
    </div>
  );
}
