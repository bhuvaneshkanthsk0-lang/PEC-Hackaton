import { useEffect, useState } from "react";
import { ShoppingBag, Coins, CheckCircle2 } from "lucide-react";
import { api } from "../lib/api";

const DEMO_ITEMS = [
  { id: 1, name: "Reusable Steel Bottle", description: "500ml insulated bottle", points_cost: 300, stock: 25, category: "Eco Products" },
  { id: 2, name: "Cloth Tote Bag", description: "Organic cotton tote", points_cost: 150, stock: 50, category: "Eco Products" },
  { id: 3, name: "₹100 Recycling Voucher", description: "Redeemable at partner centers", points_cost: 500, stock: 20, category: "Vouchers" },
];

export default function Store() {
  const [items, setItems] = useState(DEMO_ITEMS);
  const [category, setCategory] = useState("All");
  const [redeemedId, setRedeemedId] = useState(null);
  const [error, setError] = useState(null);

  useEffect(() => {
    api.storeItems().then(setItems).catch(() => setItems(DEMO_ITEMS));
  }, []);

  const categories = ["All", ...new Set(items.map((i) => i.category))];
  const visible = category === "All" ? items : items.filter((i) => i.category === category);

  const redeem = async (item) => {
    setError(null);
    try {
      await api.storeRedeem(item.id);
      setRedeemedId(item.id);
      setItems((prev) => prev.map((i) => (i.id === item.id ? { ...i, stock: i.stock - 1 } : i)));
    } catch (e) {
      setError(e.message || "Could not redeem — check your points balance");
    }
  };

  return (
    <div className="max-w-2xl mx-auto py-8 px-4">
      <h1 className="text-2xl font-bold text-gray-800 mb-1 flex items-center gap-2">
        <ShoppingBag className="w-6 h-6 text-green-600" /> Store
      </h1>
      <p className="text-gray-500 mb-6">Redeem your points for eco-products and vouchers</p>

      <div className="flex gap-2 mb-6 overflow-x-auto">
        {categories.map((c) => (
          <button
            key={c}
            onClick={() => setCategory(c)}
            className={`px-4 py-1.5 rounded-full text-sm font-medium whitespace-nowrap transition ${
              category === c ? "bg-green-600 text-white" : "bg-white border border-gray-200 text-gray-600 hover:bg-gray-50"
            }`}
          >
            {c}
          </button>
        ))}
      </div>

      {error && <p className="text-sm text-red-500 mb-4">{error}</p>}

      <div className="grid sm:grid-cols-2 gap-4">
        {visible.map((item) => (
          <div key={item.id} className="bg-white rounded-xl border border-gray-100 p-4 flex flex-col">
            <p className="font-semibold text-gray-800">{item.name}</p>
            <p className="text-sm text-gray-500 mb-3 flex-1">{item.description}</p>
            <div className="flex items-center justify-between mb-3">
              <span className="flex items-center gap-1 text-green-700 font-semibold text-sm">
                <Coins className="w-4 h-4" /> {item.points_cost} pts
              </span>
              <span className="text-xs text-gray-400">{item.stock} left</span>
            </div>
            <button
              onClick={() => redeem(item)}
              disabled={item.stock <= 0}
              className="w-full flex items-center justify-center gap-2 bg-green-600 hover:bg-green-700 disabled:opacity-40 text-white py-2 rounded-lg text-sm font-medium transition"
            >
              {redeemedId === item.id ? (
                <>
                  <CheckCircle2 className="w-4 h-4" /> Redeemed
                </>
              ) : item.stock <= 0 ? (
                "Out of Stock"
              ) : (
                "Redeem"
              )}
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}
