import { useEffect, useState } from "react";
import { Bell, Ruler, MapPinned, LogOut, Trash2 } from "lucide-react";
import { api } from "../lib/api";

function Toggle({ checked, onChange }) {
  return (
    <button
      onClick={() => onChange(!checked)}
      className={`w-11 h-6 rounded-full transition relative flex-shrink-0 ${checked ? "bg-green-600" : "bg-gray-300"}`}
    >
      <span
        className={`absolute top-0.5 left-0.5 w-5 h-5 bg-white rounded-full transition-transform ${
          checked ? "translate-x-5" : "translate-x-0"
        }`}
      />
    </button>
  );
}

export default function SettingsPage() {
  const [settings, setSettings] = useState({ notifications_enabled: true, unit_pref: "kg", share_location: true });

  useEffect(() => {
    api.getSettings().then(setSettings).catch(() => {});
  }, []);

  const update = (patch) => {
    const next = { ...settings, ...patch };
    setSettings(next);
    api.updateSettings(patch).catch(() => {});
  };

  return (
    <div className="max-w-xl mx-auto py-8 px-4">
      <h1 className="text-2xl font-bold text-gray-800 mb-6">Settings</h1>

      <div className="bg-white rounded-2xl border border-gray-100 divide-y divide-gray-100 mb-6">
        <div className="flex items-center justify-between p-4">
          <div className="flex items-center gap-3">
            <Bell className="w-5 h-5 text-green-600" />
            <div>
              <p className="text-gray-800 font-medium">Notifications</p>
              <p className="text-xs text-gray-500">Get updates on report status and rewards</p>
            </div>
          </div>
          <Toggle checked={settings.notifications_enabled} onChange={(v) => update({ notifications_enabled: v })} />
        </div>

        <div className="flex items-center justify-between p-4">
          <div className="flex items-center gap-3">
            <Ruler className="w-5 h-5 text-green-600" />
            <div>
              <p className="text-gray-800 font-medium">Units</p>
              <p className="text-xs text-gray-500">Weight unit for recycling value</p>
            </div>
          </div>
          <select
            value={settings.unit_pref}
            onChange={(e) => update({ unit_pref: e.target.value })}
            className="border border-gray-200 rounded-lg px-2 py-1 text-sm"
          >
            <option value="kg">kg</option>
            <option value="lb">lb</option>
          </select>
        </div>

        <div className="flex items-center justify-between p-4">
          <div className="flex items-center gap-3">
            <MapPinned className="w-5 h-5 text-green-600" />
            <div>
              <p className="text-gray-800 font-medium">Share location on leaderboard</p>
              <p className="text-xs text-gray-500">Lets nearby users see your city ranking</p>
            </div>
          </div>
          <Toggle checked={settings.share_location} onChange={(v) => update({ share_location: v })} />
        </div>
      </div>

      <button className="w-full flex items-center justify-center gap-2 border border-gray-200 hover:bg-gray-50 text-gray-700 py-2.5 rounded-lg font-medium mb-3">
        <LogOut className="w-4 h-4" /> Log Out
      </button>
      <button className="w-full flex items-center justify-center gap-2 text-red-500 hover:bg-red-50 py-2.5 rounded-lg font-medium">
        <Trash2 className="w-4 h-4" /> Delete Account
      </button>
    </div>
  );
}
