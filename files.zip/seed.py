"""Run once after the DB is created: python seed.py"""

from app import create_app
from extensions import db
from models import MaterialRate, StoreItem, Badge

app = create_app()

MATERIAL_RATES = [
    ("Plastic Bottle", 8, 15),
    ("Mixed Plastic Wrapper", 2, 6),
    ("Aluminum Can", 90, 120),
    ("Cardboard", 6, 12),
    ("Glass Bottle", 2, 5),
    ("E-Waste (Battery)", 20, 60),
    ("Food Scraps", 0, 0),
]

STORE_ITEMS = [
    ("Reusable Steel Bottle", "500ml insulated bottle", 300, 25, "Eco Products"),
    ("Cloth Tote Bag", "Organic cotton tote", 150, 50, "Eco Products"),
    ("₹100 Recycling Partner Voucher", "Redeemable at partner scrap centers", 500, 20, "Vouchers"),
    ("Compost Starter Kit", "Home composting kit", 400, 15, "Eco Products"),
    ("10% Off Local Cafe", "Discount coupon", 200, 100, "Vouchers"),
]

BADGES = [
    ("First Scan", "Completed your first AI waste detection", "camera"),
    ("Community Reporter", "Submitted 5 public waste reports", "map-pin"),
    ("Recycling Regular", "Logged 10 recycled items", "recycle"),
    ("Top 10 Leaderboard", "Reached the weekly top 10", "trophy"),
]

with app.app_context():
    if not MaterialRate.query.first():
        for waste_type, lo, hi in MATERIAL_RATES:
            db.session.add(MaterialRate(waste_type=waste_type, min_rate=lo, max_rate=hi, unit="kg"))

    if not StoreItem.query.first():
        for name, desc, cost, stock, category in STORE_ITEMS:
            db.session.add(StoreItem(name=name, description=desc, points_cost=cost, stock=stock, category=category))

    if not Badge.query.first():
        for name, desc, icon in BADGES:
            db.session.add(Badge(name=name, description=desc, icon=icon))

    db.session.commit()
    print("Seed complete.")
