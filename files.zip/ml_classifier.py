"""
Waste image classifier.

Real mode: loads a MobileNetV2-based model (TensorFlow/Keras) if
`tensorflow` is installed and a model file is present at MODEL_PATH.

Mock mode (default, zero setup): if TensorFlow / the model file isn't
available, falls back to a deterministic pseudo-classifier so the rest
of the API is fully testable without any ML setup. Swap in the real
model later — every route that calls `classify_image()` stays the same.
"""

import hashlib
import io
import os

MODEL_PATH = os.path.join(os.path.dirname(__file__), "waste_model.h5")

WASTE_CLASSES = [
    {"waste_type": "Plastic Bottle", "category": "Plastic"},
    {"waste_type": "Aluminum Can", "category": "Metal"},
    {"waste_type": "Cardboard", "category": "Paper"},
    {"waste_type": "Glass Bottle", "category": "Glass"},
    {"waste_type": "E-Waste (Battery)", "category": "E-Waste"},
    {"waste_type": "Food Scraps", "category": "Organic"},
    {"waste_type": "Mixed Plastic Wrapper", "category": "Plastic"},
]

_tf_model = None
_tf_available = False

try:
    if os.path.exists(MODEL_PATH):
        import tensorflow as tf  # noqa: F401

        _tf_model = tf.keras.models.load_model(MODEL_PATH)
        _tf_available = True
except Exception:
    # TensorFlow not installed, or model failed to load — stay in mock mode.
    _tf_model = None
    _tf_available = False


def _mock_classify(image_bytes: bytes):
    """Deterministic stand-in classifier: hashes the image bytes to pick
    a class + a plausible confidence, so results are stable per image
    (not random each call) while requiring no ML dependencies."""
    digest = hashlib.sha256(image_bytes).hexdigest()
    idx = int(digest[:8], 16) % len(WASTE_CLASSES)
    confidence = 0.75 + (int(digest[8:10], 16) / 255) * 0.24  # ~0.75–0.99
    result = WASTE_CLASSES[idx]
    return result["waste_type"], result["category"], round(confidence, 3)


def _real_classify(image_bytes: bytes):
    """Real MobileNetV2 inference path. Adjust preprocessing/labels to
    match however the model was actually trained/fine-tuned."""
    import numpy as np
    from PIL import Image

    img = Image.open(io.BytesIO(image_bytes)).convert("RGB").resize((224, 224))
    arr = np.array(img) / 255.0
    arr = np.expand_dims(arr, axis=0)

    preds = _tf_model.predict(arr)
    idx = int(np.argmax(preds[0]))
    confidence = float(preds[0][idx])
    idx = idx % len(WASTE_CLASSES)  # safety clamp until real label map is wired in
    result = WASTE_CLASSES[idx]
    return result["waste_type"], result["category"], round(confidence, 3)


def classify_image(file_storage) -> dict:
    """file_storage: a werkzeug FileStorage from request.files['image']."""
    image_bytes = file_storage.read()
    file_storage.seek(0)  # allow the caller to read/save it again afterward

    if _tf_available:
        waste_type, category, confidence = _real_classify(image_bytes)
        mode = "model"
    else:
        waste_type, category, confidence = _mock_classify(image_bytes)
        mode = "mock"

    return {
        "waste_type": waste_type,
        "category": category,
        "confidence": confidence,
        "mode": mode,  # surface this so the frontend/devs know if it's real or mock
    }
