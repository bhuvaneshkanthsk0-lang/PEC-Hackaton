import { useEffect, useState } from "react";
import { Trophy, Medal } from "lucide-react";
import { api } from "../lib/api";

const DEMO = {
  results: [
    { rank: 1, user_id: 1, name: "Sarah J.", points: 980 },
    { rank: 2, user_id: 2, name: "Mike D.", points: 750 },
    { rank: 3, user_id: 3, name: "Chloe W.", points: 610 },
    { rank: 4, user_id: 4, name: "You", points: 240 },
  ],
};

const PODIUM_COLORS = ["bg-amber-400", "bg-gray-300", "bg-amber-700"];

export default function Leaderboard() {
  const [scope, setScope] = useState("alltime");
  const [data, setData] = useState(DEMO);

  useEffect(() => {
    api.leaderboard(scope).then(setData).catch(() => setData(DEMO));
  }, [scope]);

  const results = data.results || [];
  const top3 = results.slice(0, 3);
  const rest = results.slice(3);

  return (
    <div className="max-w-xl mx-auto py-8 px-4">
      <h1 className="text-2xl font-bold text-gray-800 mb-1 flex items-center gap-2">
        <Trophy className="w-6 h-6 text-amber-500" /> Leaderboard
      </h1>
      <p className="text-gray-500 mb-6">See how you rank in the community</p>

      <div className="flex gap-2 mb-6">
        {["weekly", "monthly", "alltime"].map((s) => (
          <button
            key={s}
            onClick={() => setScope(s)}
            className={`px-4 py-1.5 rounded-full text-sm font-medium capitalize transition ${
              scope === s ? "bg-green-600 text-white" : "bg-white border border-gray-200 text-gray-600 hover:bg-gray-50"
            }`}
          >
            {s === "alltime" ? "All-time" : s}
          </button>
        ))}
      </div>

      {top3.length > 0 && (
        <div className="flex items-end justify-center gap-3 mb-6">
          {[top3[1], top3[0], top3[2]].filter(Boolean).map((u, i) => {
            const order = [1, 0, 2][i]; // visual order: 2nd, 1st, 3rd
            const height = order === 0 ? "h-28" : order === 1 ? "h-20" : "h-16";
            return (
              <div key={u.user_id} className="flex flex-col items-center w-24">
                <div className={`w-12 h-12 rounded-full ${PODIUM_COLORS[order]} flex items-center justify-center text-white font-bold mb-2`}>
                  {u.name?.[0] || "?"}
                </div>
                <p className="text-sm font-medium text-gray-800 truncate w-full text-center">{u.name}</p>
                <p className="text-xs text-gray-500 mb-2">{u.points} pts</p>
                <div className={`w-full ${height} bg-green-100 rounded-t-lg flex items-start justify-center pt-1`}>
                  <span className="text-green-700 font-bold">#{order + 1}</span>
                </div>
              </div>
            );
          })}
        </div>
      )}

      <div className="space-y-2">
        {rest.map((u) => (
          <div
            key={u.user_id}
            className={`flex items-center justify-between bg-white rounded-xl border p-3 ${
              u.name === "You" ? "border-green-300 bg-green-50" : "border-gray-100"
            }`}
          >
            <div className="flex items-center gap-3">
              <span className="w-6 text-center text-gray-400 font-medium">{u.rank}</span>
              <div className="w-8 h-8 rounded-full bg-gray-200 flex items-center justify-center text-sm font-semibold text-gray-600">
                {u.name?.[0] || "?"}
              </div>
              <p className="font-medium text-gray-800">{u.name}</p>
            </div>
            <div className="flex items-center gap-1 text-green-700 font-semibold text-sm">
              <Medal className="w-4 h-4" /> {u.points} pts
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
