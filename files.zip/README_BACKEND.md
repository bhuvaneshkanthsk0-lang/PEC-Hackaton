# EcoTrack AI — Backend (Flask + SQLite)

## Setup

```bash
cd backend
python -m venv venv
venv\Scripts\activate        # Windows
# source venv/bin/activate   # macOS/Linux

pip install -r requirements.txt
cp .env.example .env         # then edit values if needed
python app.py                # creates ecotrack.db automatically
python seed.py                # populates material rates, store items, badges
```

Server runs at `http://localhost:5000`. Health check: `GET /api/health`.

## Notes

- **Auth**: JWT (`Flask-JWT-Extended`). Send `Authorization: Bearer <access_token>`
  on protected routes after `/api/auth/login` or `/api/auth/signup`.
- **ML classifier**: `ml_classifier.py` runs in **mock mode** by default (no
  TensorFlow required) so the whole API is testable immediately — it returns
  deterministic, plausible-looking results per image. To go live: install
  `tensorflow`, drop a trained model at `backend/waste_model.h5`, and it
  switches to real inference automatically (see `mode` field in `/api/detect`
  responses — `"model"` vs `"mock"`).
- **Uploaded images** are saved to `backend/uploads/` and served at
  `/uploads/<filename>`.
- **Google Maps**: set `GOOGLE_MAPS_API_KEY` in `.env` to enable
  `/api/recycle/centers`. Without it, the endpoint returns an empty list
  instead of erroring.
- **CORS**: defaults to allowing `http://localhost:5173` (Vite's default
  port). Change `CORS_ORIGINS` in `.env` if your frontend runs elsewhere.

## Full endpoint list

```
POST   /api/auth/signup
POST   /api/auth/login
POST   /api/auth/refresh
POST   /api/auth/logout

GET    /api/dashboard/summary
GET    /api/activity/recent

POST   /api/detect                       (multipart: image)
GET    /api/detect/history

GET    /api/recycle-value?waste_type=
POST   /api/recycle/log
GET    /api/recycle/centers?lat=&lng=

POST   /api/reports                      (JSON or multipart: image)
GET    /api/reports
GET    /api/reports/nearby?lat=&lng=
PATCH  /api/reports/<id>/status

GET    /api/rewards/summary
GET    /api/rewards/rules

GET    /api/leaderboard?scope=weekly|monthly|alltime

GET    /api/history

GET    /api/store/items
POST   /api/store/redeem
GET    /api/store/orders

GET    /api/user/<id>
PUT    /api/user/<id>
GET    /api/user/<id>/impact

GET    /api/settings
PUT    /api/settings

GET    /api/faq
POST   /api/support/ticket
```
