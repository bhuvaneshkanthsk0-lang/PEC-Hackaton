from datetime import datetime, timedelta

from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from sqlalchemy import func

from extensions import db
from models import User, PointsLedger, Badge, UserBadge, StoreItem, Redemption, Scan, Report
from points import POINTS_RULES

game_bp = Blueprint("gamification", __name__, url_prefix="/api")


# ---------------- Rewards ----------------

@game_bp.get("/rewards/summary")
@jwt_required()
def rewards_summary():
    user_id = get_jwt_identity()
    user = User.query.get_or_404(user_id)

    earned_badge_ids = [ub.badge_id for ub in UserBadge.query.filter_by(user_id=user.id).all()]
    badges = Badge.query.filter(Badge.id.in_(earned_badge_ids)).all() if earned_badge_ids else []

    return jsonify({
        "points": user.points,
        "level": user.level,
        "badges": [b.to_dict() for b in badges],
    })


@game_bp.get("/rewards/rules")
def rewards_rules():
    return jsonify(POINTS_RULES)


# ---------------- Leaderboard ----------------

@game_bp.get("/leaderboard")
def leaderboard():
    scope = request.args.get("scope", "alltime")  # weekly | monthly | alltime

    query = db.session.query(
        User.id, User.name, User.avatar_url,
        func.coalesce(func.sum(PointsLedger.points), 0).label("total_points"),
    ).join(PointsLedger, PointsLedger.user_id == User.id)

    if scope == "weekly":
        since = datetime.utcnow() - timedelta(days=7)
        query = query.filter(PointsLedger.created_at >= since)
    elif scope == "monthly":
        since = datetime.utcnow() - timedelta(days=30)
        query = query.filter(PointsLedger.created_at >= since)

    rows = query.group_by(User.id).order_by(func.sum(PointsLedger.points).desc()).limit(50).all()

    results = [
        {"rank": i + 1, "user_id": r.id, "name": r.name, "avatar_url": r.avatar_url, "points": int(r.total_points)}
        for i, r in enumerate(rows)
    ]
    return jsonify({"scope": scope, "results": results})


# ---------------- History (merged timeline) ----------------

@game_bp.get("/history")
@jwt_required()
def history():
    user_id = get_jwt_identity()

    events = []
    for s in Scan.query.filter_by(user_id=user_id).all():
        events.append({"type": "scan", "id": s.id, "title": f"Scanned {s.waste_type}",
                       "image_url": s.image_url, "created_at": s.created_at.isoformat()})
    for r in Report.query.filter_by(user_id=user_id).all():
        events.append({"type": "report", "id": r.id, "title": f"Reported {r.waste_type} ({r.status})",
                       "image_url": r.image_url, "created_at": r.created_at.isoformat()})
    for p in PointsLedger.query.filter_by(user_id=user_id).all():
        sign = "+" if p.points >= 0 else ""
        events.append({"type": "points", "id": p.id, "title": f"{sign}{p.points} pts ({p.action_type})",
                       "image_url": None, "created_at": p.created_at.isoformat()})
    for red in Redemption.query.filter_by(user_id=user_id).all():
        item = StoreItem.query.get(red.item_id)
        events.append({"type": "redemption", "id": red.id,
                       "title": f"Redeemed {item.name if item else 'an item'}",
                       "image_url": item.image_url if item else None,
                       "created_at": red.created_at.isoformat()})

    events.sort(key=lambda e: e["created_at"], reverse=True)
    return jsonify(events[:100])


# ---------------- Store ----------------

@game_bp.get("/store/items")
def store_items():
    items = StoreItem.query.order_by(StoreItem.points_cost.asc()).all()
    return jsonify([i.to_dict() for i in items])


@game_bp.post("/store/redeem")
@jwt_required()
def store_redeem():
    user_id = get_jwt_identity()
    user = User.query.get_or_404(user_id)
    data = request.get_json(force=True) or {}
    item_id = data.get("item_id")

    item = StoreItem.query.get_or_404(item_id)

    if item.stock <= 0:
        return jsonify({"error": "This item is out of stock"}), 400
    if user.points < item.points_cost:
        return jsonify({"error": "Not enough points"}), 400

    item.stock -= 1
    user.points -= item.points_cost

    ledger = PointsLedger(user_id=user.id, action_type="redeem", points=-item.points_cost,
                          ref_type="store_item", ref_id=item.id)
    redemption = Redemption(user_id=user.id, item_id=item.id)

    db.session.add_all([ledger, redemption])
    db.session.commit()

    return jsonify({"redemption": redemption.to_dict(), "remaining_points": user.points}), 201


@game_bp.get("/store/orders")
@jwt_required()
def store_orders():
    user_id = get_jwt_identity()
    orders = Redemption.query.filter_by(user_id=user_id).order_by(Redemption.created_at.desc()).all()
    result = []
    for o in orders:
        item = StoreItem.query.get(o.item_id)
        d = o.to_dict()
        d["item"] = item.to_dict() if item else None
        result.append(d)
    return jsonify(result)
