import { useEffect, useState } from "react";
import { Award, Camera, MapPin, Recycle, ShoppingBag } from "lucide-react";
import { api } from "../lib/api";

const LEVELS = [
  { name: "Seedling", threshold: 0 },
  { name: "Sprout", threshold: 100 },
  { name: "Grower", threshold: 300 },
  { name: "Guardian", threshold: 700 },
  { name: "Eco Champion", threshold: 1500 },
];

export default function Rewards({ onNavigate }) {
  const [summary, setSummary] = useState({ points: 240, level: "Sprout", badges: [] });
  const [rules, setRules] = useState({ scan: 5, report: 15, recycle: 10 });

  useEffect(() => {
    api.rewardsSummary().then(setSummary).catch(() => {});
    api.rewardsRules().then(setRules).catch(() => {});
  }, []);

  const currentIdx = LEVELS.findIndex((l) => l.name === summary.level);
  const next = LEVELS[currentIdx + 1];
  const prevThreshold = LEVELS[currentIdx]?.threshold ?? 0;
  const progressPct = next
    ? Math.min(100, ((summary.points - prevThreshold) / (next.threshold - prevThreshold)) * 100)
    : 100;

  return (
    <div className="max-w-xl mx-auto py-8 px-4">
      <h1 className="text-2xl font-bold text-gray-800 mb-1">Rewards</h1>
      <p className="text-gray-500 mb-6">Track your points, level, and badges</p>

      <div className="bg-gradient-to-br from-green-600 to-green-700 rounded-2xl p-6 text-white mb-6">
        <div className="flex items-center justify-between mb-3">
          <div>
            <p className="text-green-100 text-sm">Current Level</p>
            <p className="text-2xl font-bold">{summary.level}</p>
          </div>
          <div className="text-right">
            <p className="text-green-100 text-sm">Points</p>
            <p className="text-2xl font-bold">{summary.points}</p>
          </div>
        </div>
        {next && (
          <>
            <div className="w-full h-2 bg-green-800/40 rounded-full overflow-hidden">
              <div className="h-full bg-white rounded-full transition-all" style={{ width: `${progressPct}%` }} />
            </div>
            <p className="text-xs text-green-100 mt-2">
              {next.threshold - summary.points > 0 ? `${next.threshold - summary.points} pts to ${next.name}` : `Ready for ${next.name}`}
            </p>
          </>
        )}
      </div>

      <h2 className="text-lg font-semibold text-gray-800 mb-3">Ways to Earn</h2>
      <div className="grid grid-cols-3 gap-3 mb-6">
        {[
          { icon: Camera, label: "Scan Item", pts: rules.scan },
          { icon: MapPin, label: "Report Waste", pts: rules.report },
          { icon: Recycle, label: "Recycle", pts: rules.recycle },
        ].map(({ icon: Icon, label, pts }) => (
          <div key={label} className="bg-white rounded-xl border border-gray-100 p-4 text-center">
            <Icon className="w-6 h-6 text-green-600 mx-auto mb-2" />
            <p className="text-sm font-medium text-gray-700">{label}</p>
            <p className="text-xs text-green-600 font-semibold">+{pts} pts</p>
          </div>
        ))}
      </div>

      <h2 className="text-lg font-semibold text-gray-800 mb-3">Badges</h2>
      <div className="grid grid-cols-2 gap-3 mb-6">
        {(summary.badges?.length ? summary.badges : [{ id: "placeholder", name: "Scan an item to earn your first badge", description: "" }]).map(
          (b) => (
            <div key={b.id} className="bg-white rounded-xl border border-gray-100 p-4 flex items-center gap-3">
              <Award className="w-5 h-5 text-amber-500 flex-shrink-0" />
              <p className="text-sm text-gray-700">{b.name}</p>
            </div>
          )
        )}
      </div>

      <button
        onClick={() => onNavigate?.("Store")}
        className="w-full flex items-center justify-center gap-2 bg-green-600 hover:bg-green-700 text-white py-2.5 rounded-lg font-medium transition"
      >
        <ShoppingBag className="w-4 h-4" /> Redeem Points in Store
      </button>
    </div>
  );
}
