import { useEffect, useState } from "react";
import { User, Camera, MapPin, Recycle, Leaf, Pencil } from "lucide-react";
import { api } from "../lib/api";

export default function Profile({ currentUser = { id: 1, name: "You", email: "you@example.com" } }) {
  const [profile, setProfile] = useState({ ...currentUser, points: 240, level: "Sprout" });
  const [impact, setImpact] = useState({ total_scans: 12, total_reports: 4, estimated_kg_diverted: 3.6 });
  const [editing, setEditing] = useState(false);
  const [name, setName] = useState(currentUser.name);

  useEffect(() => {
    api.getUser(currentUser.id).then(setProfile).catch(() => {});
    api.userImpact(currentUser.id).then(setImpact).catch(() => {});
  }, [currentUser.id]);

  const save = async () => {
    try {
      const updated = await api.updateUser(currentUser.id, { name });
      setProfile(updated);
    } catch {
      setProfile((p) => ({ ...p, name }));
    }
    setEditing(false);
  };

  return (
    <div className="max-w-xl mx-auto py-8 px-4">
      <h1 className="text-2xl font-bold text-gray-800 mb-6">Profile</h1>

      <div className="bg-white rounded-2xl border border-gray-100 p-6 mb-6 flex items-center gap-4">
        <div className="w-16 h-16 rounded-full bg-green-100 flex items-center justify-center">
          <User className="w-8 h-8 text-green-600" />
        </div>
        <div className="flex-1">
          {editing ? (
            <input
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="border border-gray-200 rounded-lg px-2 py-1 text-lg font-semibold w-full mb-1"
            />
          ) : (
            <p className="text-lg font-semibold text-gray-800">{profile.name}</p>
          )}
          <p className="text-sm text-gray-500">{profile.email}</p>
          <p className="text-xs text-green-600 font-medium mt-1">{profile.level} · {profile.points} pts</p>
        </div>
        <button
          onClick={() => (editing ? save() : setEditing(true))}
          className="p-2 rounded-lg border border-gray-200 hover:bg-gray-50 text-gray-500"
        >
          <Pencil className="w-4 h-4" />
        </button>
      </div>

      <h2 className="text-lg font-semibold text-gray-800 mb-3">Your Impact</h2>
      <div className="grid grid-cols-3 gap-3">
        {[
          { icon: Camera, label: "Scans", value: impact.total_scans },
          { icon: MapPin, label: "Reports", value: impact.total_reports },
          { icon: Leaf, label: "kg Diverted", value: impact.estimated_kg_diverted },
        ].map(({ icon: Icon, label, value }) => (
          <div key={label} className="bg-white rounded-xl border border-gray-100 p-4 text-center">
            <Icon className="w-5 h-5 text-green-600 mx-auto mb-1" />
            <p className="text-xl font-bold text-gray-800">{value}</p>
            <p className="text-xs text-gray-500">{label}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
