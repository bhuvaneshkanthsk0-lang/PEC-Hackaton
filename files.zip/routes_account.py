from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity

from extensions import db
from models import User, Scan, Report, UserSettings, SupportTicket

account_bp = Blueprint("account", __name__, url_prefix="/api")


# ---------------- Home dashboard ----------------

@account_bp.get("/dashboard/summary")
@jwt_required()
def dashboard_summary():
    user_id = get_jwt_identity()
    user = User.query.get_or_404(user_id)

    return jsonify({
        "points": user.points,
        "level": user.level,
        "total_scans": Scan.query.filter_by(user_id=user.id).count(),
        "total_reports": Report.query.filter_by(user_id=user.id).count(),
    })


@account_bp.get("/activity/recent")
@jwt_required()
def recent_activity():
    user_id = get_jwt_identity()
    limit = request.args.get("limit", default=8, type=int)

    scans = [{"type": "scan", "title": f"Scanned {s.waste_type}", "created_at": s.created_at.isoformat()}
             for s in Scan.query.filter_by(user_id=user_id).order_by(Scan.created_at.desc()).limit(limit)]
    reports = [{"type": "report", "title": f"Reported {r.waste_type}", "created_at": r.created_at.isoformat()}
               for r in Report.query.filter_by(user_id=user_id).order_by(Report.created_at.desc()).limit(limit)]

    combined = sorted(scans + reports, key=lambda e: e["created_at"], reverse=True)
    return jsonify(combined[:limit])


# ---------------- Profile ----------------

@account_bp.get("/user/<int:uid>")
@jwt_required()
def get_user(uid):
    user = User.query.get_or_404(uid)
    return jsonify(user.to_dict())


@account_bp.put("/user/<int:uid>")
@jwt_required()
def update_user(uid):
    user = User.query.get_or_404(uid)
    data = request.get_json(force=True) or {}

    for field in ("name", "avatar_url"):
        if field in data:
            setattr(user, field, data[field])

    db.session.commit()
    return jsonify(user.to_dict())


@account_bp.get("/user/<int:uid>/impact")
@jwt_required()
def user_impact(uid):
    scans = Scan.query.filter_by(user_id=uid).count()
    reports = Report.query.filter_by(user_id=uid).count()
    # Simple placeholder formula — refine once real weight/value data exists.
    est_kg_diverted = round(scans * 0.3, 1)
    return jsonify({
        "total_scans": scans,
        "total_reports": reports,
        "estimated_kg_diverted": est_kg_diverted,
    })


# ---------------- Settings ----------------

@account_bp.get("/settings")
@jwt_required()
def get_settings():
    user_id = get_jwt_identity()
    settings = UserSettings.query.get(user_id)
    if not settings:
        settings = UserSettings(user_id=user_id)
        db.session.add(settings)
        db.session.commit()
    return jsonify(settings.to_dict())


@account_bp.put("/settings")
@jwt_required()
def update_settings():
    user_id = get_jwt_identity()
    settings = UserSettings.query.get(user_id) or UserSettings(user_id=user_id)
    data = request.get_json(force=True) or {}

    for field in ("notifications_enabled", "unit_pref", "share_location"):
        if field in data:
            setattr(settings, field, data[field])

    db.session.add(settings)
    db.session.commit()
    return jsonify(settings.to_dict())


# ---------------- Help & Support ----------------

FAQ = [
    {"q": "How does AI Waste Detection work?", "a": "Snap or upload a photo and the model classifies the waste type in a few seconds."},
    {"q": "How are points earned?", "a": "You earn points for scanning items, reporting public waste, and logging recycled items."},
    {"q": "How is recycling value calculated?", "a": "Estimated from current market rates per material type — actual prices vary by location and buyer."},
]


@account_bp.get("/faq")
def get_faq():
    return jsonify(FAQ)


@account_bp.post("/support/ticket")
@jwt_required()
def create_ticket():
    user_id = get_jwt_identity()
    data = request.get_json(force=True) or {}
    subject = (data.get("subject") or "").strip()
    message = (data.get("message") or "").strip()

    if not subject or not message:
        return jsonify({"error": "subject and message are required"}), 400

    ticket = SupportTicket(user_id=user_id, subject=subject, message=message)
    db.session.add(ticket)
    db.session.commit()
    return jsonify(ticket.to_dict()), 201
