import { useEffect, useMemo, useState } from "react";
import { Camera, MapPin, Coins, ShoppingBag, Filter } from "lucide-react";
import { api } from "../lib/api";

const ICONS = { scan: Camera, report: MapPin, points: Coins, redemption: ShoppingBag };

const DEMO = [
  { type: "scan", id: 1, title: "Scanned Plastic Bottle", created_at: new Date().toISOString() },
  { type: "points", id: 2, title: "+5 pts (scan)", created_at: new Date().toISOString() },
  { type: "report", id: 3, title: "Reported E-Waste (Pending)", created_at: new Date(Date.now() - 86400000).toISOString() },
  { type: "redemption", id: 4, title: "Redeemed Cloth Tote Bag", created_at: new Date(Date.now() - 2 * 86400000).toISOString() },
];

export default function History() {
  const [events, setEvents] = useState(DEMO);
  const [filter, setFilter] = useState("all");

  useEffect(() => {
    api.history().then(setEvents).catch(() => setEvents(DEMO));
  }, []);

  const filtered = useMemo(() => (filter === "all" ? events : events.filter((e) => e.type === filter)), [events, filter]);

  return (
    <div className="max-w-xl mx-auto py-8 px-4">
      <h1 className="text-2xl font-bold text-gray-800 mb-1">History</h1>
      <p className="text-gray-500 mb-6">All your scans, reports, points, and redemptions</p>

      <div className="flex items-center gap-2 mb-6 overflow-x-auto">
        <Filter className="w-4 h-4 text-gray-400 flex-shrink-0" />
        {["all", "scan", "report", "points", "redemption"].map((f) => (
          <button
            key={f}
            onClick={() => setFilter(f)}
            className={`px-3 py-1.5 rounded-full text-sm capitalize whitespace-nowrap transition ${
              filter === f ? "bg-green-600 text-white" : "bg-white border border-gray-200 text-gray-600 hover:bg-gray-50"
            }`}
          >
            {f}
          </button>
        ))}
      </div>

      <div className="space-y-3">
        {filtered.map((e) => {
          const Icon = ICONS[e.type] || Coins;
          return (
            <div key={`${e.type}-${e.id}`} className="bg-white rounded-xl border border-gray-100 p-4 flex items-center gap-3">
              <div className="w-9 h-9 rounded-lg bg-green-50 flex items-center justify-center flex-shrink-0">
                <Icon className="w-4 h-4 text-green-600" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-gray-800 font-medium truncate">{e.title}</p>
                <p className="text-xs text-gray-400">{new Date(e.created_at).toLocaleString()}</p>
              </div>
            </div>
          );
        })}
        {filtered.length === 0 && <p className="text-center text-gray-400 py-10">Nothing here yet.</p>}
      </div>
    </div>
  );
}
