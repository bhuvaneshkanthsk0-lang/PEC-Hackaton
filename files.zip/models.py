from datetime import datetime
from extensions import db


def now():
    return datetime.utcnow()


class User(db.Model):
    __tablename__ = "users"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), nullable=False)
    email = db.Column(db.String(200), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    avatar_url = db.Column(db.String(500), default="")
    points = db.Column(db.Integer, default=0)
    level = db.Column(db.String(50), default="Seedling")
    created_at = db.Column(db.DateTime, default=now)
    is_active = db.Column(db.Boolean, default=True)

    def to_dict(self):
        return {
            "id": self.id,
            "name": self.name,
            "email": self.email,
            "avatar_url": self.avatar_url,
            "points": self.points,
            "level": self.level,
            "created_at": self.created_at.isoformat(),
        }


class Scan(db.Model):
    __tablename__ = "scans"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    image_url = db.Column(db.String(500))
    waste_type = db.Column(db.String(80))
    category = db.Column(db.String(80))
    confidence = db.Column(db.Float)
    created_at = db.Column(db.DateTime, default=now)

    def to_dict(self):
        return {
            "id": self.id,
            "user_id": self.user_id,
            "image_url": self.image_url,
            "waste_type": self.waste_type,
            "category": self.category,
            "confidence": self.confidence,
            "created_at": self.created_at.isoformat(),
        }


class Report(db.Model):
    __tablename__ = "reports"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    image_url = db.Column(db.String(500))
    waste_type = db.Column(db.String(80))
    lat = db.Column(db.Float, nullable=False)
    lng = db.Column(db.Float, nullable=False)
    description = db.Column(db.String(500), default="")
    status = db.Column(db.String(30), default="Pending")  # Pending / Verified / Resolved
    created_at = db.Column(db.DateTime, default=now)

    def to_dict(self):
        return {
            "id": self.id,
            "user_id": self.user_id,
            "image_url": self.image_url,
            "waste_type": self.waste_type,
            "lat": self.lat,
            "lng": self.lng,
            "description": self.description,
            "status": self.status,
            "created_at": self.created_at.isoformat(),
        }


class PointsLedger(db.Model):
    __tablename__ = "points_ledger"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    action_type = db.Column(db.String(50))  # scan / report / recycle / redeem
    points = db.Column(db.Integer)  # positive = earned, negative = spent
    ref_type = db.Column(db.String(50), default="")
    ref_id = db.Column(db.Integer, nullable=True)
    created_at = db.Column(db.DateTime, default=now)

    def to_dict(self):
        return {
            "id": self.id,
            "user_id": self.user_id,
            "action_type": self.action_type,
            "points": self.points,
            "ref_type": self.ref_type,
            "ref_id": self.ref_id,
            "created_at": self.created_at.isoformat(),
        }


class MaterialRate(db.Model):
    __tablename__ = "material_rates"

    waste_type = db.Column(db.String(80), primary_key=True)
    min_rate = db.Column(db.Float)
    max_rate = db.Column(db.Float)
    unit = db.Column(db.String(20), default="kg")

    def to_dict(self):
        return {
            "waste_type": self.waste_type,
            "min_rate": self.min_rate,
            "max_rate": self.max_rate,
            "unit": self.unit,
        }


class StoreItem(db.Model):
    __tablename__ = "store_items"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(150))
    description = db.Column(db.String(500))
    points_cost = db.Column(db.Integer)
    stock = db.Column(db.Integer, default=0)
    category = db.Column(db.String(80))
    image_url = db.Column(db.String(500), default="")

    def to_dict(self):
        return {
            "id": self.id,
            "name": self.name,
            "description": self.description,
            "points_cost": self.points_cost,
            "stock": self.stock,
            "category": self.category,
            "image_url": self.image_url,
        }


class Redemption(db.Model):
    __tablename__ = "redemptions"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    item_id = db.Column(db.Integer, db.ForeignKey("store_items.id"), nullable=False)
    status = db.Column(db.String(30), default="Confirmed")
    created_at = db.Column(db.DateTime, default=now)

    def to_dict(self):
        return {
            "id": self.id,
            "user_id": self.user_id,
            "item_id": self.item_id,
            "status": self.status,
            "created_at": self.created_at.isoformat(),
        }


class Badge(db.Model):
    __tablename__ = "badges"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120))
    description = db.Column(db.String(300))
    icon = db.Column(db.String(80), default="award")

    def to_dict(self):
        return {"id": self.id, "name": self.name, "description": self.description, "icon": self.icon}


class UserBadge(db.Model):
    __tablename__ = "user_badges"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    badge_id = db.Column(db.Integer, db.ForeignKey("badges.id"), nullable=False)
    earned_at = db.Column(db.DateTime, default=now)


class SupportTicket(db.Model):
    __tablename__ = "support_tickets"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    subject = db.Column(db.String(200))
    message = db.Column(db.Text)
    status = db.Column(db.String(30), default="Open")
    created_at = db.Column(db.DateTime, default=now)

    def to_dict(self):
        return {
            "id": self.id,
            "user_id": self.user_id,
            "subject": self.subject,
            "message": self.message,
            "status": self.status,
            "created_at": self.created_at.isoformat(),
        }


class UserSettings(db.Model):
    __tablename__ = "settings"

    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), primary_key=True)
    notifications_enabled = db.Column(db.Boolean, default=True)
    unit_pref = db.Column(db.String(10), default="kg")
    share_location = db.Column(db.Boolean, default=True)

    def to_dict(self):
        return {
            "user_id": self.user_id,
            "notifications_enabled": self.notifications_enabled,
            "unit_pref": self.unit_pref,
            "share_location": self.share_location,
        }
