import { useRef, useState } from "react";
import { Camera, Upload, Loader2, RotateCcw, ArrowRight } from "lucide-react";
import { api } from "../lib/api";

export default function AIWasteDetection({ onNavigate }) {
  const fileInputRef = useRef(null);
  const [preview, setPreview] = useState(null);
  const [file, setFile] = useState(null);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState(null);
  const [error, setError] = useState(null);

  const handleFile = (f) => {
    if (!f) return;
    setFile(f);
    setPreview(URL.createObjectURL(f));
    setResult(null);
    setError(null);
  };

  const runDetection = async () => {
    if (!file) return;
    setLoading(true);
    setError(null);
    try {
      const data = await api.detect(file);
      setResult(data.scan);
    } catch (e) {
      // Fallback so the flow is still demoable without the backend running
      setResult({
        waste_type: "Plastic Bottle",
        category: "Plastic",
        confidence: 0.91,
      });
      setError("Backend not reachable — showing a demo result.");
    } finally {
      setLoading(false);
    }
  };

  const reset = () => {
    setFile(null);
    setPreview(null);
    setResult(null);
    setError(null);
  };

  return (
    <div className="max-w-xl mx-auto py-8 px-4">
      <h1 className="text-2xl font-bold text-gray-800 mb-1">AI Waste Detection</h1>
      <p className="text-gray-500 mb-6">Snap or upload a photo — we'll identify the waste type instantly.</p>

      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
        {!preview && (
          <div className="flex flex-col items-center justify-center py-12 border-2 border-dashed border-green-200 rounded-xl bg-green-50/50">
            <Camera className="w-12 h-12 text-green-600 mb-3" />
            <p className="text-gray-600 mb-4">Align the item and take a photo, or upload one</p>
            <div className="flex gap-3">
              <button
                onClick={() => fileInputRef.current?.click()}
                className="flex items-center gap-2 bg-green-600 hover:bg-green-700 text-white px-5 py-2.5 rounded-lg font-medium transition"
              >
                <Camera className="w-4 h-4" /> Take a Photo
              </button>
              <button
                onClick={() => fileInputRef.current?.click()}
                className="flex items-center gap-2 bg-white border border-gray-200 hover:bg-gray-50 text-gray-700 px-5 py-2.5 rounded-lg font-medium transition"
              >
                <Upload className="w-4 h-4" /> Upload
              </button>
            </div>
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              capture="environment"
              className="hidden"
              onChange={(e) => handleFile(e.target.files?.[0])}
            />
          </div>
        )}

        {preview && (
          <div>
            <img src={preview} alt="Selected waste item" className="w-full h-64 object-cover rounded-xl mb-4" />

            {!result && !loading && (
              <div className="flex gap-3">
                <button
                  onClick={runDetection}
                  className="flex-1 bg-green-600 hover:bg-green-700 text-white py-2.5 rounded-lg font-medium transition"
                >
                  Detect Waste Type
                </button>
                <button
                  onClick={reset}
                  className="flex items-center gap-2 px-4 py-2.5 rounded-lg border border-gray-200 text-gray-600 hover:bg-gray-50"
                >
                  <RotateCcw className="w-4 h-4" /> Retake
                </button>
              </div>
            )}

            {loading && (
              <div className="flex items-center justify-center gap-2 text-green-700 py-4">
                <Loader2 className="w-5 h-5 animate-spin" /> Analyzing image…
              </div>
            )}

            {result && (
              <div className="mt-2">
                <div className="bg-green-50 border border-green-100 rounded-xl p-4 mb-4">
                  <p className="text-sm text-green-700 font-medium mb-1">Detected</p>
                  <p className="text-xl font-bold text-gray-800">{result.waste_type}</p>
                  <p className="text-sm text-gray-500">
                    Category: {result.category}
                    {result.confidence && <> · Confidence: {Math.round(result.confidence * 100)}%</>}
                  </p>
                </div>
                {error && <p className="text-xs text-amber-600 mb-3">{error}</p>}
                <div className="flex gap-3">
                  <button
                    onClick={() => onNavigate?.("Recycle Value", { wasteType: result.waste_type })}
                    className="flex-1 flex items-center justify-center gap-2 bg-green-600 hover:bg-green-700 text-white py-2.5 rounded-lg font-medium transition"
                  >
                    See Recycle Value <ArrowRight className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => onNavigate?.("Smart Reporting", { wasteType: result.waste_type, imageUrl: preview })}
                    className="flex-1 bg-white border border-gray-200 hover:bg-gray-50 text-gray-700 py-2.5 rounded-lg font-medium transition"
                  >
                    Report It
                  </button>
                </div>
                <button onClick={reset} className="w-full text-sm text-gray-500 hover:text-gray-700 mt-3">
                  Scan another item
                </button>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
