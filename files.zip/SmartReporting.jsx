import { useEffect, useState } from "react";
import { MapPin, Send, Clock, CheckCircle2, AlertCircle } from "lucide-react";
import { api } from "../lib/api";

const STATUS_STYLES = {
  Pending: "bg-amber-50 text-amber-700 border-amber-100",
  Verified: "bg-blue-50 text-blue-700 border-blue-100",
  Resolved: "bg-green-50 text-green-700 border-green-100",
};

export default function SmartReporting({ params }) {
  const [wasteType, setWasteType] = useState(params?.wasteType || "");
  const [description, setDescription] = useState("");
  const [coords, setCoords] = useState(null);
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [myReports, setMyReports] = useState([]);

  useEffect(() => {
    navigator.geolocation?.getCurrentPosition(
      (pos) => setCoords({ lat: pos.coords.latitude, lng: pos.coords.longitude }),
      () => setCoords({ lat: 13.0827, lng: 80.2707 }) // Chennai fallback
    );
    api
      .myReports()
      .then(setMyReports)
      .catch(() =>
        setMyReports([
          { id: 1, waste_type: "Plastic Wrapper", status: "Pending", created_at: new Date().toISOString() },
          { id: 2, waste_type: "E-Waste", status: "Verified", created_at: new Date().toISOString() },
        ])
      );
  }, []);

  const submit = async () => {
    if (!wasteType || !coords) return;
    setSubmitting(true);
    try {
      const res = await api.createReport({
        waste_type: wasteType,
        description,
        lat: coords.lat,
        lng: coords.lng,
        image_url: params?.imageUrl || "",
      });
      setMyReports((prev) => [res.report, ...prev]);
    } catch {
      setMyReports((prev) => [
        { id: Date.now(), waste_type: wasteType, status: "Pending", created_at: new Date().toISOString() },
        ...prev,
      ]);
    } finally {
      setSubmitting(false);
      setSubmitted(true);
    }
  };

  return (
    <div className="max-w-xl mx-auto py-8 px-4">
      <h1 className="text-2xl font-bold text-gray-800 mb-1">Smart Reporting</h1>
      <p className="text-gray-500 mb-6">Report waste dumped in a public space</p>

      {!submitted ? (
        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 mb-6">
          <label className="block text-sm font-medium text-gray-700 mb-1">Waste Type</label>
          <input
            value={wasteType}
            onChange={(e) => setWasteType(e.target.value)}
            placeholder="e.g. Plastic Bottle"
            className="w-full border border-gray-200 rounded-lg px-3 py-2.5 mb-4 focus:outline-none focus:ring-2 focus:ring-green-500"
          />

          <label className="block text-sm font-medium text-gray-700 mb-1">Description (optional)</label>
          <textarea
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            rows={3}
            placeholder="Any extra detail that helps local authorities"
            className="w-full border border-gray-200 rounded-lg px-3 py-2.5 mb-4 focus:outline-none focus:ring-2 focus:ring-green-500"
          />

          <div className="flex items-center gap-2 text-sm text-gray-500 mb-5 bg-gray-50 rounded-lg px-3 py-2.5">
            <MapPin className="w-4 h-4 text-green-600" />
            {coords ? `Location: ${coords.lat.toFixed(4)}, ${coords.lng.toFixed(4)}` : "Getting your location…"}
          </div>

          <button
            onClick={submit}
            disabled={!wasteType || submitting}
            className="w-full flex items-center justify-center gap-2 bg-green-600 hover:bg-green-700 disabled:opacity-50 text-white py-2.5 rounded-lg font-medium transition"
          >
            <Send className="w-4 h-4" /> {submitting ? "Submitting…" : "Submit Report (+15 pts)"}
          </button>
        </div>
      ) : (
        <div className="bg-green-50 border border-green-100 rounded-xl p-4 mb-6 flex items-center gap-2 text-green-700">
          <CheckCircle2 className="w-5 h-5" /> Report submitted — thanks for keeping your area clean!
        </div>
      )}

      <h2 className="text-lg font-semibold text-gray-800 mb-3">My Reports</h2>
      <div className="space-y-3">
        {myReports.map((r) => (
          <div key={r.id} className="bg-white rounded-xl border border-gray-100 p-4 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-lg bg-gray-100 flex items-center justify-center">
                <AlertCircle className="w-4 h-4 text-gray-500" />
              </div>
              <div>
                <p className="font-medium text-gray-800">{r.waste_type}</p>
                <p className="text-xs text-gray-400 flex items-center gap-1">
                  <Clock className="w-3 h-3" /> {new Date(r.created_at).toLocaleDateString()}
                </p>
              </div>
            </div>
            <span className={`text-xs font-medium border rounded-full px-2.5 py-1 ${STATUS_STYLES[r.status] || ""}`}>
              {r.status}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}
