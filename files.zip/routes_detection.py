import os
import uuid

import requests
from flask import Blueprint, request, jsonify, current_app, url_for
from flask_jwt_extended import jwt_required, get_jwt_identity
from werkzeug.utils import secure_filename

from extensions import db
from models import User, Scan, Report, MaterialRate
from ml_classifier import classify_image
from points import award_points, POINTS_RULES

detection_bp = Blueprint("detection", __name__, url_prefix="/api")

ALLOWED_EXTS = {"png", "jpg", "jpeg", "webp"}


def _allowed(filename):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTS


def _save_image(file_storage):
    os.makedirs(current_app.config["UPLOAD_FOLDER"], exist_ok=True)
    ext = file_storage.filename.rsplit(".", 1)[1].lower()
    fname = f"{uuid.uuid4().hex}.{ext}"
    path = os.path.join(current_app.config["UPLOAD_FOLDER"], secure_filename(fname))
    file_storage.save(path)
    return f"/uploads/{fname}"


# ---------------- AI Waste Detection ----------------

@detection_bp.post("/detect")
@jwt_required()
def detect():
    user_id = get_jwt_identity()
    user = User.query.get_or_404(user_id)

    if "image" not in request.files:
        return jsonify({"error": "No image file provided (field name: 'image')"}), 400

    image = request.files["image"]
    if image.filename == "" or not _allowed(image.filename):
        return jsonify({"error": "Please upload a png/jpg/jpeg/webp image"}), 400

    result = classify_image(image)
    image_url = _save_image(image)

    scan = Scan(
        user_id=user.id,
        image_url=image_url,
        waste_type=result["waste_type"],
        category=result["category"],
        confidence=result["confidence"],
    )
    db.session.add(scan)
    db.session.commit()

    award_points(user, "scan", POINTS_RULES["scan"], ref_type="scan", ref_id=scan.id)

    return jsonify({
        "scan": scan.to_dict(),
        "points_awarded": POINTS_RULES["scan"],
        "model_mode": result["mode"],
    }), 201


@detection_bp.get("/detect/history")
@jwt_required()
def detect_history():
    user_id = get_jwt_identity()
    scans = Scan.query.filter_by(user_id=user_id).order_by(Scan.created_at.desc()).limit(50).all()
    return jsonify([s.to_dict() for s in scans])


# ---------------- Recycle Value ----------------

@detection_bp.get("/recycle-value")
def recycle_value():
    waste_type = request.args.get("waste_type", "")
    rate = MaterialRate.query.filter_by(waste_type=waste_type).first()
    if not rate:
        return jsonify({"waste_type": waste_type, "min_rate": None, "max_rate": None, "unit": "kg",
                         "message": "No rate on file for this item yet"}), 200
    return jsonify(rate.to_dict())


@detection_bp.post("/recycle/log")
@jwt_required()
def recycle_log():
    user_id = get_jwt_identity()
    user = User.query.get_or_404(user_id)
    data = request.get_json(force=True) or {}
    scan_id = data.get("scan_id")

    award_points(user, "recycle", POINTS_RULES["recycle"], ref_type="scan", ref_id=scan_id)
    return jsonify({"message": "Logged as recycled", "points_awarded": POINTS_RULES["recycle"],
                     "total_points": user.points})


@detection_bp.get("/recycle/centers")
def recycle_centers():
    lat = request.args.get("lat")
    lng = request.args.get("lng")
    api_key = current_app.config.get("GOOGLE_MAPS_API_KEY")

    if not lat or not lng:
        return jsonify({"error": "lat and lng query params are required"}), 400

    if not api_key:
        return jsonify({"message": "GOOGLE_MAPS_API_KEY not configured — returning empty list", "results": []})

    resp = requests.get(
        "https://maps.googleapis.com/maps/api/place/nearbysearch/json",
        params={"location": f"{lat},{lng}", "radius": 5000, "keyword": "recycling center", "key": api_key},
        timeout=8,
    )
    return jsonify(resp.json())


# ---------------- Smart Reporting ----------------

@detection_bp.post("/reports")
@jwt_required()
def create_report():
    user_id = get_jwt_identity()
    user = User.query.get_or_404(user_id)

    if request.is_json:
        # JSON path: reusing an image_url from a prior /api/detect scan
        data = request.get_json()
        lat, lng = data.get("lat"), data.get("lng")
        waste_type = data.get("waste_type", "Unknown")
        description = data.get("description", "")
        image_url = data.get("image_url", "")
    else:
        # multipart path: a fresh photo uploaded directly with the report
        lat = request.form.get("lat")
        lng = request.form.get("lng")
        waste_type = request.form.get("waste_type", "Unknown")
        description = request.form.get("description", "")
        image_url = ""
        if "image" in request.files and request.files["image"].filename:
            image = request.files["image"]
            if not _allowed(image.filename):
                return jsonify({"error": "Please upload a png/jpg/jpeg/webp image"}), 400
            image_url = _save_image(image)

    if lat is None or lng is None:
        return jsonify({"error": "lat and lng are required"}), 400

    report = Report(
        user_id=user.id,
        image_url=image_url,
        waste_type=waste_type,
        lat=float(lat),
        lng=float(lng),
        description=description,
    )
    db.session.add(report)
    db.session.commit()

    award_points(user, "report", POINTS_RULES["report"], ref_type="report", ref_id=report.id)

    return jsonify({"report": report.to_dict(), "points_awarded": POINTS_RULES["report"]}), 201


@detection_bp.get("/reports")
@jwt_required()
def my_reports():
    user_id = get_jwt_identity()
    reports = Report.query.filter_by(user_id=user_id).order_by(Report.created_at.desc()).all()
    return jsonify([r.to_dict() for r in reports])


@detection_bp.get("/reports/nearby")
def nearby_reports():
    lat = request.args.get("lat", type=float)
    lng = request.args.get("lng", type=float)
    radius_deg = request.args.get("radius_deg", default=0.2, type=float)  # ~22km, simple bbox filter

    query = Report.query
    if lat is not None and lng is not None:
        query = query.filter(
            Report.lat.between(lat - radius_deg, lat + radius_deg),
            Report.lng.between(lng - radius_deg, lng + radius_deg),
        )
    reports = query.order_by(Report.created_at.desc()).limit(100).all()
    return jsonify([r.to_dict() for r in reports])


@detection_bp.patch("/reports/<int:report_id>/status")
@jwt_required()
def update_report_status(report_id):
    report = Report.query.get_or_404(report_id)
    data = request.get_json(force=True) or {}
    new_status = data.get("status")

    if new_status not in {"Pending", "Verified", "Resolved"}:
        return jsonify({"error": "status must be Pending, Verified, or Resolved"}), 400

    was_pending = report.status == "Pending"
    report.status = new_status
    db.session.commit()

    if was_pending and new_status == "Verified":
        reporter = User.query.get(report.user_id)
        if reporter:
            award_points(reporter, "report_verified_bonus", POINTS_RULES["report_verified_bonus"],
                         ref_type="report", ref_id=report.id)

    return jsonify(report.to_dict())
