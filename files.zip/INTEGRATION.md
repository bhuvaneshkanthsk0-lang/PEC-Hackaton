# Wiring these pages into your existing App.jsx

Drop these files in:
```
src/lib/api.js
src/pages/AIWasteDetection.jsx
src/pages/RecycleValue.jsx
src/pages/SmartReporting.jsx
src/pages/Rewards.jsx
src/pages/Leaderboard.jsx
src/pages/History.jsx
src/pages/Profile.jsx
src/pages/Settings.jsx
src/pages/Store.jsx
src/pages/HelpSupport.jsx
```

In your existing `App.jsx`, replace the placeholder-page switch with real
components, and pass a simple `navigate(page, params)` function down so
pages can hand off context to each other (e.g. AI Detection → Recycle Value
with the detected waste type already filled in).

```jsx
import AIWasteDetection from "./pages/AIWasteDetection";
import RecycleValue from "./pages/RecycleValue";
import SmartReporting from "./pages/SmartReporting";
import Rewards from "./pages/Rewards";
import Leaderboard from "./pages/Leaderboard";
import History from "./pages/History";
import Profile from "./pages/Profile";
import Settings from "./pages/Settings";
import Store from "./pages/Store";
import HelpSupport from "./pages/HelpSupport";

// inside App component:
const [page, setPage] = useState("Home");
const [pageParams, setPageParams] = useState({});

const navigate = (nextPage, params = {}) => {
  setPage(nextPage);
  setPageParams(params);
};

function renderPage() {
  switch (page) {
    case "Home":
      return <HomePage onNavigate={navigate} />; // your existing home page
    case "Store":
      return <Store />;
    case "AI Waste Detection":
      return <AIWasteDetection onNavigate={navigate} />;
    case "Recycle Value":
      return <RecycleValue params={pageParams} />;
    case "Smart Reporting":
      return <SmartReporting params={pageParams} />;
    case "Rewards":
      return <Rewards onNavigate={navigate} />;
    case "Leaderboard":
      return <Leaderboard />;
    case "History":
      return <History />;
    case "Profile":
      return <Profile />;
    case "Settings":
      return <Settings />;
    case "Help & Support":
      return <HelpSupport />;
    default:
      return <div>Coming soon</div>;
  }
}
```

Pass `navigate` (renamed if you already have an `onNavigate` prop) to your
sidebar's click handler the same way you already do.

## Auth token

`src/lib/api.js` reads a JWT from `localStorage.getItem("ecotrack_token")`.
After your login/signup call succeeds, store it:

```js
const { access_token, user } = await api.login(email, password);
localStorage.setItem("ecotrack_token", access_token);
```

## Backend URL

`api.js` points at `http://localhost:5000` — update `BASE_URL` there if you
deploy the backend elsewhere.

## Demo-safe by default

Every page tries the real API first and falls back to inline demo data if
the request fails — so the UI looks complete even before the backend is
running, and switches to live data automatically once it is.
