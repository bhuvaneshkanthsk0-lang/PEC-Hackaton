# Prompt: Build the full EcoTrack AI frontend

Copy everything below into a new prompt when you're ready to have the
complete frontend built/polished in one pass.

---

Build the complete frontend for **EcoTrack AI** (EcoDetect), a React + Vite +
Tailwind CSS dashboard app for AI-powered waste detection and recycling
rewards, based on a hackathon pitch (EcoNetwork AI — Smart Waste Detection &
Reward, Team Phantom, PEC Hacks 4.0).

**Existing foundation (keep this):**
- Sidebar with 11 nav items: Home, Store, AI Waste Detection, Recycle Value,
  Smart Reporting, Rewards, Leaderboard, History, Profile, Settings, Help &
  Support.
- Home page is already fully built: welcome bar (credits/bell/avatar), green
  profile stats card, 4 feature cards, bottom stats strip, Recent Activity
  panel, dark green footer bar.
- Visual language: green primary palette, white rounded-2xl cards with soft
  shadows, lucide-react icons, clean sans-serif type.
- Tech: React 18, Vite, Tailwind CSS, lucide-react.

**What to build for each page** (functionally complete UI, calling a Flask
REST API at `http://localhost:5000`, with graceful fallback to inline demo
data if the API isn't reachable):

1. **AI Waste Detection** — camera/upload capture, loading state, result
   screen (waste type + confidence), "Confirm & Continue" routes to Recycle
   Value or Smart Reporting with the detected type passed along.
2. **Recycle Value** — estimated ₹/kg for the detected item, "Log as
   Recycled" (awards points), nearby recycling centers.
3. **Smart Reporting** — report form (waste type, description, GPS location,
   photo), submit for points, list of the user's own reports with status
   (Pending/Verified/Resolved).
4. **Rewards** — points balance, level progress bar, "ways to earn" grid,
   earned badges, link to Store.
5. **Leaderboard** — ranked list with podium for top 3, Weekly/Monthly/
   All-time filters, current user highlighted.
6. **History** — unified timeline of scans/reports/points/redemptions with
   type filters.
7. **Store** — redeemable items grid with category filters, points cost,
   redeem action.
8. **Profile** — avatar, name/email, editable name, impact stats (scans,
   reports, kg diverted).
9. **Settings** — notification toggle, unit preference, share-location
   toggle, logout, delete account.
10. **Help & Support** — FAQ accordion, contact/support ticket form.

**Requirements:**
- Match the existing Home page's visual style exactly — don't introduce a
  new color palette or component style.
- Each page should work standalone (own loading/error states) and also
  accept params from navigation (e.g. AI Detection passing a waste type into
  Recycle Value or Smart Reporting).
- Use a shared `src/lib/api.js` fetch client with JWT auth
  (`Authorization: Bearer <token>` from `localStorage`).
- Mobile-responsive down to a single column.
- No placeholder/lorem ipsum — use realistic labels and copy matching the
  waste/recycling domain.

**API contract to build against** (already implemented — see backend):
```
POST /api/auth/signup | /api/auth/login
POST /api/detect                    (multipart image) → {waste_type, category, confidence}
GET  /api/recycle-value?waste_type=
POST /api/recycle/log
POST /api/reports | GET /api/reports | GET /api/reports/nearby
GET  /api/rewards/summary | /api/rewards/rules
GET  /api/leaderboard?scope=weekly|monthly|alltime
GET  /api/history
GET  /api/store/items | POST /api/store/redeem | GET /api/store/orders
GET  /api/user/:id | PUT /api/user/:id | GET /api/user/:id/impact
GET  /api/settings | PUT /api/settings
GET  /api/faq | POST /api/support/ticket
```

Deliver each page as its own component file under `src/pages/`, plus the
updated `src/App.jsx` wiring them into the existing sidebar navigation.
