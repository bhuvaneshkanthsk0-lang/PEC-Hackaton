import { useEffect, useState } from "react";
import { HelpCircle, ChevronDown, Send, CheckCircle2 } from "lucide-react";
import { api } from "../lib/api";

const DEMO_FAQ = [
  { q: "How does AI Waste Detection work?", a: "Snap or upload a photo and the model classifies the waste type in a few seconds." },
  { q: "How are points earned?", a: "You earn points for scanning items, reporting public waste, and logging recycled items." },
  { q: "How is recycling value calculated?", a: "Estimated from current market rates per material type — actual prices vary by location and buyer." },
];

export default function HelpSupport() {
  const [faq, setFaq] = useState(DEMO_FAQ);
  const [openIdx, setOpenIdx] = useState(null);
  const [subject, setSubject] = useState("");
  const [message, setMessage] = useState("");
  const [sent, setSent] = useState(false);

  useEffect(() => {
    api.faq().then(setFaq).catch(() => setFaq(DEMO_FAQ));
  }, []);

  const submit = async () => {
    if (!subject || !message) return;
    try {
      await api.createTicket(subject, message);
    } catch {
      /* demo mode */
    }
    setSent(true);
    setSubject("");
    setMessage("");
  };

  return (
    <div className="max-w-xl mx-auto py-8 px-4">
      <h1 className="text-2xl font-bold text-gray-800 mb-1 flex items-center gap-2">
        <HelpCircle className="w-6 h-6 text-green-600" /> Help & Support
      </h1>
      <p className="text-gray-500 mb-6">Find answers or reach out to our team</p>

      <h2 className="text-lg font-semibold text-gray-800 mb-3">FAQ</h2>
      <div className="bg-white rounded-2xl border border-gray-100 divide-y divide-gray-100 mb-8">
        {faq.map((item, i) => (
          <div key={i}>
            <button
              onClick={() => setOpenIdx(openIdx === i ? null : i)}
              className="w-full flex items-center justify-between p-4 text-left"
            >
              <span className="font-medium text-gray-800">{item.q}</span>
              <ChevronDown className={`w-4 h-4 text-gray-400 transition-transform ${openIdx === i ? "rotate-180" : ""}`} />
            </button>
            {openIdx === i && <p className="px-4 pb-4 text-sm text-gray-500">{item.a}</p>}
          </div>
        ))}
      </div>

      <h2 className="text-lg font-semibold text-gray-800 mb-3">Contact Us</h2>
      {sent ? (
        <div className="flex items-center gap-2 bg-green-50 border border-green-100 text-green-700 rounded-xl p-4">
          <CheckCircle2 className="w-5 h-5" /> Thanks — we'll get back to you soon.
        </div>
      ) : (
        <div className="bg-white rounded-2xl border border-gray-100 p-6">
          <input
            value={subject}
            onChange={(e) => setSubject(e.target.value)}
            placeholder="Subject"
            className="w-full border border-gray-200 rounded-lg px-3 py-2.5 mb-3 focus:outline-none focus:ring-2 focus:ring-green-500"
          />
          <textarea
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            rows={4}
            placeholder="How can we help?"
            className="w-full border border-gray-200 rounded-lg px-3 py-2.5 mb-4 focus:outline-none focus:ring-2 focus:ring-green-500"
          />
          <button
            onClick={submit}
            className="w-full flex items-center justify-center gap-2 bg-green-600 hover:bg-green-700 text-white py-2.5 rounded-lg font-medium transition"
          >
            <Send className="w-4 h-4" /> Send Message
          </button>
        </div>
      )}
    </div>
  );
}
