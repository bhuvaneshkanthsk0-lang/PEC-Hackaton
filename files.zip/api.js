const BASE_URL = "http://localhost:5000";

function getToken() {
  return localStorage.getItem("ecotrack_token");
}

async function request(path, { method = "GET", body, isForm = false, auth = true } = {}) {
  const headers = {};
  if (!isForm) headers["Content-Type"] = "application/json";
  if (auth) {
    const token = getToken();
    if (token) headers["Authorization"] = `Bearer ${token}`;
  }

  const res = await fetch(`${BASE_URL}${path}`, {
    method,
    headers,
    body: isForm ? body : body ? JSON.stringify(body) : undefined,
  });

  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || `Request failed (${res.status})`);
  return data;
}

export const api = {
  // Auth
  signup: (name, email, password) => request("/api/auth/signup", { method: "POST", body: { name, email, password }, auth: false }),
  login: (email, password) => request("/api/auth/login", { method: "POST", body: { email, password }, auth: false }),

  // Dashboard / Home
  dashboardSummary: () => request("/api/dashboard/summary"),
  recentActivity: (limit = 8) => request(`/api/activity/recent?limit=${limit}`),

  // AI Waste Detection
  detect: (file) => {
    const form = new FormData();
    form.append("image", file);
    return request("/api/detect", { method: "POST", body: form, isForm: true });
  },
  detectHistory: () => request("/api/detect/history"),

  // Recycle Value
  recycleValue: (wasteType) => request(`/api/recycle-value?waste_type=${encodeURIComponent(wasteType)}`, { auth: false }),
  recycleLog: (scanId) => request("/api/recycle/log", { method: "POST", body: { scan_id: scanId } }),
  recycleCenters: (lat, lng) => request(`/api/recycle/centers?lat=${lat}&lng=${lng}`, { auth: false }),

  // Smart Reporting
  createReport: (payload) => request("/api/reports", { method: "POST", body: payload }),
  myReports: () => request("/api/reports"),
  nearbyReports: (lat, lng) => request(`/api/reports/nearby?lat=${lat}&lng=${lng}`, { auth: false }),

  // Rewards
  rewardsSummary: () => request("/api/rewards/summary"),
  rewardsRules: () => request("/api/rewards/rules", { auth: false }),

  // Leaderboard
  leaderboard: (scope = "alltime") => request(`/api/leaderboard?scope=${scope}`, { auth: false }),

  // History
  history: () => request("/api/history"),

  // Store
  storeItems: () => request("/api/store/items", { auth: false }),
  storeRedeem: (itemId) => request("/api/store/redeem", { method: "POST", body: { item_id: itemId } }),
  storeOrders: () => request("/api/store/orders"),

  // Profile
  getUser: (id) => request(`/api/user/${id}`),
  updateUser: (id, payload) => request(`/api/user/${id}`, { method: "PUT", body: payload }),
  userImpact: (id) => request(`/api/user/${id}/impact`),

  // Settings
  getSettings: () => request("/api/settings"),
  updateSettings: (payload) => request("/api/settings", { method: "PUT", body: payload }),

  // Help & Support
  faq: () => request("/api/faq", { auth: false }),
  createTicket: (subject, message) => request("/api/support/ticket", { method: "POST", body: { subject, message } }),
};
