from extensions import db
from models import User, PointsLedger

POINTS_RULES = {
    "scan": 5,
    "report": 15,
    "report_verified_bonus": 10,
    "recycle": 10,
    "signup_bonus": 20,
}

LEVELS = [
    (0, "Seedling"),
    (100, "Sprout"),
    (300, "Grower"),
    (700, "Guardian"),
    (1500, "Eco Champion"),
]


def level_for_points(points: int) -> str:
    level = LEVELS[0][1]
    for threshold, name in LEVELS:
        if points >= threshold:
            level = name
    return level


def award_points(user: User, action_type: str, points: int, ref_type: str = "", ref_id: int = None):
    """Adds a ledger entry, updates the user's running total + level."""
    entry = PointsLedger(
        user_id=user.id,
        action_type=action_type,
        points=points,
        ref_type=ref_type,
        ref_id=ref_id,
    )
    db.session.add(entry)

    user.points = max(0, (user.points or 0) + points)
    user.level = level_for_points(user.points)

    db.session.commit()
    return entry
